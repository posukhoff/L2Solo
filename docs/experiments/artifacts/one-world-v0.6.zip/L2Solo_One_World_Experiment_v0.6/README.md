# L2Solo — One World Experiment v0.6

**Scope:** local, standalone synthetic Java 21 benchmark. **No GitHub sync.** This is not a Lineage II server and does not demonstrate that the full L2Solo can serve 7,000 Account on a consumer PC.

## Fixed in v0.6

The old v0.5 used `--combat 5600` with `--accounts 7000` and assigned a permanent COMBAT occupation to the first 5,600 Accounts. **This was a fixed 80% test fixture, not emergent behaviour.** The new benchmark no longer takes `--combat`:

- `--accounts`: how many autonomous Account identities participate.
- `--characters`: how many Character identities are present in the one shared simulated world; defaults to the Account count. This is independent from the number currently attempting combat.
- **COMBAT / CRAFT / COURIER / SOCIAL**: mutable Account activities, chosen from individual preferences, available stock, nearby threats and scripted raid/siege opportunities. No preallocated combat quota or fixed target percentage.
- Combat-disabled Character **remain in the world and are targetable**. Their action/move events stop; switching back schedules actions from the current game-time boundary. Received damage generates a threat signal.
- Coarse Activity reevaluation is modeled every 2 game seconds and on threat pressure; this is an experiment fixture, not the final ADR-002 decision algorithm.
- Both DETAIL and BATCH operate on the same Character state and Economy, and are checked for identical results and resource conservation.

**Important semantics:** `combat_activity_characters` is how many Character *intend to participate in combat*. It is **not** how many actually attack at each instant. `characters_acting_this_second` counts distinct Character who made an attack or used a skill during that game second. `present_characters` is the number in the world, irrespective of current activity.

## Commands

```bash
# JDK 21, no dependencies
javac -encoding UTF-8 CombatPrototype.java WorldEconomyExperiment.java PopulationWorldExperiment.java PopulationTrace.java SkillRulesTest.java
java SkillRulesTest
java PopulationWorldExperiment --test

# 7000 Account / 7000 Character
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 7000 --seconds 8 --repeats 1

# 7000 Account / 10000 Character (stress only)
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 10000 --seconds 8 --repeats 1

# See activity changes every game second
java -Xmx2g PopulationTrace 7000 7000 12 42
```

`./RUN.sh` compiles, runs correctness tests and runs the 7k baseline and activity trace. Benchmark CSVs bundled alongside sources.

## Verified results (single preliminary cloud runs)

| Scenario (8 game seconds) | Account | Present Character | COMBAT at beginning | COMBAT at end | Character acting in final second | Activity switches | DETAIL | BATCH |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Baseline | 7,000 | 7,000 | 3,727 | 5,084 | 4,123 | 3,693 | 3355 ms | 2770 ms |
| Additional Character stress | 7,000 | 10,000 | 5,356 | 6,920 | 5,006 | 4,527 | 5659 ms | 4886 ms |

For the 7,000-Character 12-second trace, at second 12: COMBAT Activity = 4,940 Character; 3,578 Character executed an attack/skill during that second. This variability comes from changes in inventory, encounters and scripted world events. Neither number is a target quota.

The DETAIL and BATCH runs have equal economy/combat digests and performed-event counts for both measured scenarios. Inventory conservation is checked every simulated second.

## Limits — do not confuse the benchmark with the product

1. **Economic inventories are still Account-level in this synthetic model.** Authentic L2Solo requires separate authoritative Character inventories and Account/CP/Clan warehouses according to ADR-001. A 10,000-Character stress profile does **not** validate inventory isolation or concurrent control of multiple Character belonging to one Account.
2. Account decision logic uses a lightweight synthetic score, not the complete Goal/Activity/Obligation model. It samples every 2 seconds and uses scripted raid/siege opportunities. It does not claim an emergent simulation of a realistic server population.
3. Positions of noncombat Character are seeded near their regional market at world initialization. Later travel is incremental; geodata/pathfinding is not implemented. Extra Character in the simultaneous-presence stress case have limited noncombat behavior.
4. PvE, small PvP, raid and siege **encounter layouts** are staged at preselected map locations. Their fixture shares of the world are not shares of Account activities. Real choices of encounter type and travel are future work.
5. Simplified skills/HP, NPC, PvP and economy, no real L2 formulas, network, database durability, geodata, market knowledge model or true human client. These measurements cannot establish the 7,000-Account product goal.
6. One-run times are not production benchmarks and are not comparable to previous synthetic versions as claims about actual server capacity. The extra-Character profile is purely to stress a higher entity count.

**Next experiment:** replace synthetic decision scoring and initial holdings with a slice of the approved Account decision model, preserve individual Character inventory and test the combined world continuously at the target hardware. No need to pick Worker/ECS/GPU ahead of evidence.
