import java.util.*;

/** Periodic counters: combat intent versus Characters executing an action. */
public final class PopulationTrace {
    public static void main(String[] args) {
        int accounts=args.length>0?Integer.parseInt(args[0]):7000;
        int characters=args.length>1?Integer.parseInt(args[1]):accounts;
        int seconds=args.length>2?Integer.parseInt(args[2]):12;
        long seed=args.length>3?Long.parseLong(args[3]):42;
        var state=new PopulationWorldExperiment.State(accounts,characters,seconds,seed,CombatPrototype.Mode.BATCH);
        state.combatAtStart=state.countCombat();
        System.out.println("game_second,accounts,present_characters,combat_activity_characters,characters_acting_this_second,accounts_combat_activity,accounts_crafting,accounts_courier,accounts_social,activity_changes,threat_events,transactions,combat_actions");
        for(int s=1;s<=seconds;s++){
            state.step(s*1000);
            int[] roles=new int[4];
            for(var act:state.activity)roles[act.ordinal()]++;
            long tradeCount=state.fieldTrades;
            for(var market:state.markets)tradeCount+=market.trades;
            System.out.printf(Locale.ROOT,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d%n",
                    s,accounts,characters,state.combatAtEnd,state.actingLastSecond,
                    roles[0],roles[1],roles[2],roles[3],state.switches,state.threatened,
                    tradeCount,state.world.combatActions);
        }
        state.conservation();
    }
}
