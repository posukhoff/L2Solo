import java.util.*;

/** Synthetic v0.6: Account count != Character count != participants currently in combat. */
public final class PopulationWorldExperiment {
    enum Activity { COMBAT, CRAFT, COURIER, SOCIAL }
    static final int[][] HUBS={{2500,250},{24000,250},{46000,250},{62000,250}};
    static final int HUB_RADIUS=600, FIELD_RADIUS=240, WALK_SPEED=950;

    static final class State implements CombatPrototype.CombatEconomyHook {
        final int accountsCount, charactersCount;
        final long seed;
        final CombatPrototype.World world;
        final WorldEconomyExperiment.Account[] accounts;
        final WorldEconomyExperiment.Market[] markets=new WorldEconomyExperiment.Market[4];
        final Activity[] activity;
        final int[] owner, home, courierTarget, threatenedUntil;
        final boolean[] courierHomeward;
        final int[][] accountCharacters;
        final int[] lastCharacterActions;
        long initialAdena,initialOre,initialShots, loot,fees,usedShots,madeShots,usedOre;
        long fieldTrades, courierSteps, socialSteps, decisions, switches, threatened;
        long combatNs,decisionNs,economyNs;
        int combatAtStart, combatAtEnd,combatMin=Integer.MAX_VALUE,combatMax;
        int actingLastSecond, actingMax;
        int[] lastCounts=new int[4];

        State(int n,int c,int seconds,long seed,CombatPrototype.Mode mode) {
            if(n<30||c<n||seconds<2||seconds>120)
                throw new IllegalArgumentException("Need 30+ Accounts, at least one present Character/Account, 2-120 game seconds");
            accountsCount=n;charactersCount=c;this.seed=seed;
            world=new CombatPrototype.World(CombatPrototype.Scenario.MIXED_WORLD,mode,
                    CombatPrototype.Search.GRID,c,seconds*1000,seed);
            accounts=new WorldEconomyExperiment.Account[n];activity=new Activity[n];owner=new int[c];
            home=new int[n];courierTarget=new int[n];Arrays.fill(courierTarget,-1);
            courierHomeward=new boolean[n];threatenedUntil=new int[n];
            for(int i=0;i<4;i++)markets[i]=new WorldEconomyExperiment.Market();
            ArrayList<ArrayList<Integer>> tmp=new ArrayList<>();
            for(int i=0;i<n;i++)tmp.add(new ArrayList<>());
            for(int cid=0;cid<c;cid++){owner[cid]=cid%n;tmp.get(owner[cid]).add(cid);}
            accountCharacters=new int[n][];lastCharacterActions=new int[c];
            for(int i=0;i<n;i++)accountCharacters[i]=tmp.get(i).stream().mapToInt(Integer::intValue).toArray();
            for(int i=0;i<n;i++){
                var a=new WorldEconomyExperiment.Account(i,WorldEconomyExperiment.Occupation.SOCIAL);
                long h=CombatPrototype.mix(seed^((i+1L)*0x9e3779b97f4a7c15L));
                // Initial wealth/stock varies by Account, not by a prescribed occupation quota.
                a.adena=350+Long.remainderUnsigned(h,800);
                a.ore=(int)Long.remainderUnsigned(h>>>12,12);
                a.shots=(int)Long.remainderUnsigned(h>>>22,18);
                accounts[i]=a;home[i]=zone(i,c);
                initialAdena+=a.adena;initialOre+=a.ore;initialShots+=a.shots;
            }
            world.economyHook=this;
            chooseActivities(0,true);
        }
        static int zone(int cid,int c){int pve=c*45/100,pvp=c*20/100,raid=c*15/100;
            return cid<pve?0:cid<pve+pvp?1:cid<pve+pvp+raid?2:3;}
        static long dist2(int ax,int ay,int bx,int by){long dx=(long)ax-bx,dy=(long)ay-by;return dx*dx+dy*dy;}
        int px(int i){return world.actors[i].x;} int py(int i){return world.actors[i].y;}
        boolean atHub(int i){int z=home[i];return dist2(px(i),py(i),HUBS[z][0],HUBS[z][1])<=HUB_RADIUS*HUB_RADIUS;}
        int preference(int id,int offset){long h=CombatPrototype.mix(seed+(id+1L)*0x632be59bd9b4e019L);
            return (int)((h>>>offset)&63);}
        int score(int id,Activity kind,int now,boolean nearEnemy){
            var a=accounts[id];boolean siege=home[id]==3&&now>=4000&&now<12000;
            boolean raid=home[id]==2&&now>=6000&&now<14000;
            return switch(kind){
                case COMBAT -> 30+preference(id,0)+(nearEnemy?22:-8)
                        +(now<threatenedUntil[id]?70:0)+(siege?38:0)+(raid?22:0)
                        -(a.supplyNeeded?16:0)-(world.actors[id].hp*3<world.actors[id].maxHp?16:0);
                case CRAFT -> 18+preference(id,6)+(a.ore>=2?27:-22)
                        +(a.shots<=3?13:-10)+(a.adena<3?-50:0);
                case COURIER -> 15+preference(id,12)+(a.shots>4?12:0)+(a.adena>20?10:-15);
                case SOCIAL -> 24+preference(id,18)+(a.ore==0&&a.shots==0?18:0);
            };
        }
        void chooseActivities(int now,boolean initial){
            long start=System.nanoTime();
            for(int id=0;id<accountsCount;id++){
                var previous=activity[id];
                boolean near=world.nearestEnemy(world.actors[id],CombatPrototype.SEEK_RANGE)!=null;
                Activity best=null;int bestScore=Integer.MIN_VALUE;
                for(Activity candidate:Activity.values()){
                    int score=score(id,candidate,now,near);
                    if(score>bestScore){bestScore=score;best=candidate;}
                }
                if(previous!=null&&best!=previous&&bestScore<score(id,previous,now,near)+10)best=previous;
                decisions++;
                if(best==previous)continue;
                activity[id]=best;
                if(previous!=null)switches++;
                for(int cid:accountCharacters[id]){
                    world.setCombatActive(cid,best==Activity.COMBAT,now);
                    if(initial&&best!=Activity.COMBAT){
                        var actor=world.actors[cid];int oldX=actor.x,oldY=actor.y;
                        actor.x=HUBS[home[id]][0]+(id%13)*3;
                        actor.y=HUBS[home[id]][1]+(id%17)*3;
                        world.grid.moved(actor,oldX,oldY);
                    }
                }
                courierTarget[id]=-1;courierHomeward[id]=false;
            }
            decisionNs+=System.nanoTime()-start;
        }
        @Override public void onPlayerAction(int cid,CombatPrototype.Skill skill,int at){
            int id=owner[cid];var a=accounts[id];
            if(a.shots>0){a.shots--;usedShots++;}
            if(a.shots<2)a.supplyNeeded=true;
        }
        @Override public void onLootAward(int cid,int at){accounts[owner[cid]].ore++;loot++;}
        @Override public void onPlayerAttacked(int cid,int at){
            int id=owner[cid];if(activity[id]!=Activity.COMBAT&&at+3000>threatenedUntil[id]){
                threatenedUntil[id]=at+3000;threatened++;
            }
        }
        void list(int id,WorldEconomyExperiment.Good good,int qty,int price){
            if(atHub(id))markets[home[id]].list(accounts[id],good,qty,price);
        }
        int buy(int id,WorldEconomyExperiment.Good good,int qty,int maxPrice){
            return atHub(id)?markets[home[id]].buy(accounts[id],good,qty,maxPrice):0;
        }
        void marketStep(){
            for(int id=0;id<accountsCount;id++){
                var a=accounts[id];
                switch(activity[id]){
                    case CRAFT -> {
                        if(!atHub(id))break;
                        if(a.ore<6)buy(id,WorldEconomyExperiment.Good.ORE,8,6);
                        int make=Math.min(2,a.ore/2);
                        if(make>0&&a.adena>=make){a.ore-=2*make;a.shots+=12*make;
                            a.adena-=make;usedOre+=2L*make;madeShots+=12L*make;fees+=make;}
                        if(a.shots>12)list(id,WorldEconomyExperiment.Good.SHOT,Math.min(24,a.shots-12),3);
                    }
                    case COMBAT -> {
                        if(!atHub(id))break;
                        if(a.ore>1)list(id,WorldEconomyExperiment.Good.ORE,a.ore,4);
                        if(a.supplyNeeded&&buy(id,WorldEconomyExperiment.Good.SHOT,8,4)>0)
                            a.supplyNeeded=false;
                    }
                    case COURIER -> {
                        if(!atHub(id))break;
                        if(a.ore>0)list(id,WorldEconomyExperiment.Good.ORE,a.ore,5);
                        if(a.shots<7)buy(id,WorldEconomyExperiment.Good.SHOT,12,4);
                    }
                    case SOCIAL -> {}
                }
            }
        }
        void move(int id,int tx,int ty){
            var actor=world.actors[id];long dx=(long)tx-actor.x,dy=(long)ty-actor.y;
            double distance=Math.sqrt(dx*dx+dy*dy);
            if(distance<=0)return;
            int oldX=actor.x,oldY=actor.y;double speed=Math.min(distance,WALK_SPEED);
            actor.x+=(int)Math.round(dx*speed/distance);
            actor.y+=(int)Math.round(dy*speed/distance);
            world.grid.moved(actor,oldX,oldY);
            accounts[id].x=actor.x;accounts[id].y=actor.y;
            courierSteps++;
        }
        int localFighter(int id){
            int candidates=charactersCount;
            int start=Math.floorMod((int)CombatPrototype.mix(seed+id),candidates);
            for(int k=0;k<candidates;k++){
                int cid=(start+k)%candidates;
                if(owner[cid]!=id&&home[owner[cid]]==home[id]
                        &&activity[owner[cid]]==Activity.COMBAT)return cid;
            }
            return -1;
        }
        void exchange(int id,int cid){
            int buyerId=owner[cid];
            if(id==buyerId)return;
            var courier=accounts[id]; var fighter=accounts[buyerId]; var target=world.actors[cid];
            if(dist2(px(id),py(id),target.x,target.y)>(long)FIELD_RADIUS*FIELD_RADIUS)return;
            int ore=Math.min(3,Math.min(fighter.ore,(int)(courier.adena/4)));
            if(ore>0){fighter.ore-=ore;courier.ore+=ore;courier.adena-=ore*4L;
                fighter.adena+=ore*4L;fieldTrades++;}
            int shots=fighter.supplyNeeded?Math.min(5,Math.min(courier.shots,(int)(fighter.adena/4))):0;
            if(shots>0){courier.shots-=shots;fighter.shots+=shots;fighter.adena-=shots*4L;
                courier.adena+=shots*4L;fighter.supplyNeeded=false;fieldTrades++;}
        }
        void movementAndCourierStep(){
            for(int id=0;id<accountsCount;id++){
                Activity mode=activity[id];
                if(mode==Activity.COMBAT)continue;
                if(mode!=Activity.COURIER){
                    if(!atHub(id))move(id,HUBS[home[id]][0],HUBS[home[id]][1]);
                    continue;
                }
                int cid=courierTarget[id];
                if(cid<0||activity[owner[cid]]!=Activity.COMBAT){
                    courierTarget[id]=cid=localFighter(id);courierHomeward[id]=false;
                }
                if(cid<0){move(id,HUBS[home[id]][0],HUBS[home[id]][1]);continue;}
                if(courierHomeward[id]){
                    move(id,HUBS[home[id]][0],HUBS[home[id]][1]);
                    if(atHub(id)){courierTarget[id]=-1;courierHomeward[id]=false;}
                }else{
                    var target=world.actors[cid];move(id,target.x,target.y);
                    if(dist2(px(id),py(id),target.x,target.y)<=(long)FIELD_RADIUS*FIELD_RADIUS){
                        exchange(id,cid);courierHomeward[id]=true;
                    }
                }
            }
        }
        void socialStep(){
            for(int id=0;id<accountsCount;id++)if(activity[id]==Activity.SOCIAL){
                accounts[id].socialParty=home[id]*100000+id/9;socialSteps++;
            }
        }
        long hash(){
            long h=0xcbf29ce484222325L;
            for(int id=0;id<accountsCount;id++){
                var a=accounts[id];
                long[] v={id,a.adena,a.ore,a.shots,a.socialParty,a.supplyNeeded?1:0,
                        activity[id].ordinal(),courierTarget[id],courierHomeward[id]?1:0,threatenedUntil[id]};
                for(long x:v)h=(h^x)*0x100000001b3L;
            }
            for(var market:markets)h=(h^market.digest())*0x100000001b3L;
            return h;
        }
        void conservation(){
            long adena=0,ore=0,shots=0;
            for(var a:accounts){
                if(a.adena<0||a.ore<0||a.shots<0)throw new AssertionError("negative inventory");
                adena+=a.adena;ore+=a.ore;shots+=a.shots;
            }
            for(var market:markets){ore+=market.escrow(WorldEconomyExperiment.Good.ORE);
                shots+=market.escrow(WorldEconomyExperiment.Good.SHOT);}
            if(adena+fees!=initialAdena||ore+usedOre!=initialOre+loot||shots+usedShots!=initialShots+madeShots)
                throw new AssertionError("World economy not conserved");
        }
        int countCombat(){int total=0;
            for(int cid=0;cid<charactersCount;cid++)if(world.actors[cid].combatActive)total++;
            return total;
        }
        void step(int toMs){
            if(toMs%1000!=0)throw new IllegalArgumentException("whole seconds only");
            int startMs=toMs-1000;
            // Do NOT reassess Goal/Activity for every action; reevaluate after meaningful world intervals.
            if(startMs>0&&startMs%2000==0)chooseActivities(startMs,false);
            long tick=System.nanoTime();world.advanceTo(toMs);combatNs+=System.nanoTime()-tick;
            tick=System.nanoTime();marketStep();movementAndCourierStep();economyNs+=System.nanoTime()-tick;
            socialStep();conservation();
            int active=countCombat();combatAtEnd=active;
            combatMin=Math.min(combatMin,active);combatMax=Math.max(combatMax,active);
            int acted=0;
            for(int cid=0;cid<charactersCount;cid++){
                var actor=world.actors[cid];int actions=actor.attacks+actor.spells;
                if(actions>lastCharacterActions[cid])acted++;
                lastCharacterActions[cid]=actions;
            }
            actingLastSecond=acted;actingMax=Math.max(actingMax,acted);
            for(Activity a:activity)lastCounts[a.ordinal()]++;
        }
        Result finish(long elapsed){
            var b=world.run();long trades=fieldTrades;
            for(var m:markets)trades+=m.trades;
            return new Result(accountsCount,charactersCount,combatAtStart,combatAtEnd,combatMin,combatMax,
                    actingLastSecond,actingMax,decisions,switches,threatened,b.events(),b.combatActions(),b.healEffects(),loot,trades,
                    madeShots,usedShots,courierSteps,socialSteps,elapsed,combatNs,decisionNs,economyNs,
                    lastCounts[0],lastCounts[1],lastCounts[2],lastCounts[3],hash(),b.digest());
        }
    }
    record Result(int accounts,int characters,int initialCombat,int finalCombat,int minCombat,int maxCombat,
                  int actedLastSecond,int actedMax,long decisions,long activityChanges,long threatEvents,long events,long actions,long heals,
                  long loot,long trades,long crafted,long consumed,long courierSteps,long socialSteps,
                  long elapsedNs,long combatNs,long decisionNs,long economyNs,
                  long combatSamples,long craftSamples,long courierSamples,long socialSamples,
                  long economyHash,long combatHash){
        boolean same(Result b){return economyHash==b.economyHash&&combatHash==b.combatHash
                &&events==b.events&&trades==b.trades&&loot==b.loot&&activityChanges==b.activityChanges;}
    }
    static Result run(int accounts,int characters,int seconds,long seed,CombatPrototype.Mode mode){
        var state=new State(accounts,characters,seconds,seed,mode);
        state.combatAtStart=state.countCombat();
        long start=System.nanoTime();
        for(int t=1000;t<=seconds*1000;t+=1000)state.step(t);
        state.conservation();return state.finish(System.nanoTime()-start);
    }
    static void test(){
        for(long seed:new long[]{7,42,901})for(int accounts:new int[]{300,700})
            for(int characters:new int[]{accounts,accounts+accounts/5}){
                var detail=run(accounts,characters,10,seed,CombatPrototype.Mode.DETAIL);
                var batch=run(accounts,characters,10,seed,CombatPrototype.Mode.BATCH);
                if(!detail.same(batch))throw new AssertionError("DETAIL/BATCH diverged: "+detail+" / "+batch);
                if(detail.initialCombat==characters)throw new AssertionError("All Characters are preassigned combat");
                if(detail.actedLastSecond<=0||detail.actedLastSecond>detail.finalCombat)
                    throw new AssertionError("Invalid actual actions per last second");
                if(detail.activityChanges==0)throw new AssertionError("Activities never change");
                if(detail.actions==0||detail.heals==0||detail.trades==0||detail.courierSteps==0)
                    throw new AssertionError("All required subsystems must run: "+detail);
            }
        // A noncombat Character stays in the shared authoritative combat state and can be attacked.
        var threatWorld=new State(300,300,10,42,CombatPrototype.Mode.BATCH);
        int noncombat=-1;
        for(int cid=0;cid<300;cid++)if(threatWorld.activity[cid]!=Activity.COMBAT){noncombat=cid;break;}
        if(noncombat<0)throw new AssertionError("Missing noncombat fixture");
        var target=threatWorld.world.actors[noncombat];
        var npc=threatWorld.world.actors[300];
        int before=target.hp;
        threatWorld.world.damage(npc,target,15,200);
        if(target.hp!=before-15||threatWorld.threatenedUntil[noncombat]<=200)
            throw new AssertionError("Noncombat Character lost world interaction or threat signal");
        System.out.println("PASS distinct Account/Character counts; emergent Activities; conservation; exact DETAIL/BATCH");
    }
    public static void main(String[] args){
        if(Arrays.asList(args).contains("--test")){test();return;}
        int accounts=7000,characters=-1,seconds=8,repeats=2;long seed=42;
        for(int i=0;i<args.length;i++){
            if(i+1>=args.length)throw new IllegalArgumentException("Missing value for "+args[i]);
            switch(args[i]){
                case "--accounts" -> accounts=Integer.parseInt(args[++i]);
                case "--characters" -> characters=Integer.parseInt(args[++i]);
                case "--seconds" -> seconds=Integer.parseInt(args[++i]);
                case "--repeats" -> repeats=Integer.parseInt(args[++i]);
                case "--seed" -> seed=Long.parseLong(args[++i]);
                case "--combat" -> throw new IllegalArgumentException("--combat removed: participating Character are chosen by world events");
                default -> throw new IllegalArgumentException("Unknown option "+args[i]);
            }
        }
        if(characters<0)characters=accounts;
        if(repeats<1)throw new IllegalArgumentException();
        System.out.println("mode,accounts,present_characters,combat_initial,combat_final,combat_min,combat_max,acted_last_second,acted_max,decisions,activity_changes,threat_events,events,actions,heals,loot,trades,crafted,consumed,courier_moves,social_events,elapsed_ms,combat_ms,decision_ms,economy_ms,combat_activity_samples,craft_activity_samples,courier_activity_samples,social_activity_samples,economy_hash,combat_hash");
        for(int iteration=0;iteration<repeats;iteration++){
            var detail=run(accounts,characters,seconds,seed,CombatPrototype.Mode.DETAIL);
            var batch=run(accounts,characters,seconds,seed,CombatPrototype.Mode.BATCH);
            if(!detail.same(batch))throw new AssertionError("DETAIL != BATCH at run "+iteration);
            for(var r:new Result[]{detail,batch}){
                System.out.printf(Locale.ROOT,
                        "%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,%d,%d,%d,%d,%016x,%016x%n",
                        r==detail?"DETAIL":"BATCH",r.accounts,r.characters,r.initialCombat,r.finalCombat,
                        r.minCombat,r.maxCombat,r.actedLastSecond,r.actedMax,r.decisions,r.activityChanges,r.threatEvents,r.events,
                        r.actions,r.heals,r.loot,r.trades,r.crafted,r.consumed,r.courierSteps,r.socialSteps,
                        r.elapsedNs/1e6,r.combatNs/1e6,r.decisionNs/1e6,r.economyNs/1e6,
                        r.combatSamples,r.craftSamples,r.courierSamples,r.socialSamples,r.economyHash,r.combatHash);
            }
        }
    }
}
