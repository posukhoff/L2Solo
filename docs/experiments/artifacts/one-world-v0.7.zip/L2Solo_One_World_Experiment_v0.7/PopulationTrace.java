import java.util.*;

/** Time series: Accounts choose goals; present Character != combat Character. */
public final class PopulationTrace {
    public static void main(String[] args) {
        int accounts=args.length>0?Integer.parseInt(args[0]):7000;
        int characters=args.length>1?Integer.parseInt(args[1]):accounts;
        int seconds=args.length>2?Integer.parseInt(args[2]):16;
        long seed=args.length>3?Long.parseLong(args[3]):42;
        var state=new PopulationWorldExperiment.State(accounts,characters,seconds,seed,CombatPrototype.Mode.BATCH);
        state.combatAtStart=state.countCombat();
        System.out.println("game_second,accounts,present_characters,combat_activity_characters,characters_acting_this_second,accounts_combat,accounts_crafting,accounts_courier,accounts_social,decisions,event_wakes,activity_changes,threat_events,warehouse_transfers,transactions,combat_actions");
        for(int s=1;s<=seconds;s++){
            state.step(s*1000);
            long tradeCount=state.fieldTrades;
            for(var market:state.ledger.markets)tradeCount+=market.matches;
            System.out.printf(Locale.ROOT,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d%n",
                    s,accounts,characters,state.combatAtEnd,state.actingLastSecond,
                    state.lastCounts[0],state.lastCounts[1],state.lastCounts[2],state.lastCounts[3],
                    state.decisions,state.eventWakes,state.switches,state.threatened,state.ledger.warehouseTransfers,
                    tradeCount,state.world.combatActions);
        }
        state.conservation();
    }
}
