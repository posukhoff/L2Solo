import java.util.*;

/**
 * v0.4 exploratory INTEGRATED workload, not Lineage II economy rules or a server.
 * One combat world and 7k accounts share time. Combat awards feed scarce goods; trades,
 * crafting and consumables change exact inventories with conservation checks.
 */
public final class WorldEconomyExperiment {
    enum Occupation { COMBAT, CRAFTER, COURIER, SOCIAL }
    enum Good { ORE, SHOT }
    static final class Account {
        final int id;
        final Occupation occupation;
        long adena;
        int ore, shots;
        int x, y, destination, socialParty = -1;
        boolean supplyNeeded, inTransit;
        Account(int id, Occupation job) {
            this.id = id; occupation = job;
            adena = job == Occupation.CRAFTER ? 3000 : 500;
            ore = job == Occupation.CRAFTER ? 20 : 0;
            shots = job == Occupation.CRAFTER ? 45 : job == Occupation.COMBAT ? 2 : 0;
            if (job == Occupation.COURIER) { x = 900 + id % 300; destination = 0; }
        }
        int quantity(Good item) { return item == Good.ORE ? ore : shots; }
        void change(Good item, int n) {
            if (item == Good.ORE) ore = Math.addExact(ore,n);
            else shots = Math.addExact(shots,n);
            if (ore < 0 || shots < 0) throw new AssertionError("Negative goods for account " + id);
        }
    }
    static final class Order {
        final Account owner;
        final Good item;
        final int price;
        final long seq;
        int quantity;
        Order(Account owner,Good item,int price,long seq,int qty) {
            this.owner = owner; this.item = item; this.price = price; this.seq = seq; quantity = qty;
        }
    }
    static final class Market {
        @SuppressWarnings("unchecked")
        final PriorityQueue<Order>[] offers = new PriorityQueue[] {
            new PriorityQueue<>(Comparator.<Order>comparingInt(o->o.price).thenComparingLong(o->o.seq)),
            new PriorityQueue<>(Comparator.<Order>comparingInt(o->o.price).thenComparingLong(o->o.seq))
        };
        long nextSeq, listings, trades, failedBuys, tradedOre, tradedShots, tradeAdena;
        void list(Account a, Good good, int qty, int price) {
            if (qty <= 0 || price <= 0 || qty > a.quantity(good)) throw new IllegalArgumentException("Unfunded listing");
            a.change(good,-qty); // reserve goods in escrow; never duplicate them
            offers[good.ordinal()].add(new Order(a,good,price,nextSeq++,qty));
            listings++;
        }
        int buy(Account buyer, Good good, int want, int maxPrice) {
            if (want <= 0) throw new IllegalArgumentException();
            int filled = 0;
            PriorityQueue<Order> queue = offers[good.ordinal()];
            while (filled < want && !queue.isEmpty()) {
                Order o = queue.peek();
                if (o.price > maxPrice || buyer.adena < o.price) break;
                if (o.owner == buyer) break; // self trades are not needed here
                int take = (int) Math.min(Math.min((long)(want-filled), (long)o.quantity), buyer.adena / o.price);
                if (take == 0) break;
                long cost = (long)take * o.price;
                buyer.adena -= cost;
                o.owner.adena += cost;
                buyer.change(good,take);
                o.quantity -= take;
                if (o.quantity == 0) queue.poll();
                filled += take;
                trades++;
                tradeAdena += cost;
                if (good == Good.ORE) tradedOre += take;
                else tradedShots += take;
            }
            if (filled == 0) failedBuys++;
            return filled;
        }
        long escrow(Good good) {
            long count=0;
            for(Order o:offers[good.ordinal()]) count+=o.quantity;
            return count;
        }
        long digest() {
            long result=0xcbf29ce484222325L;
            for (Good g:Good.values()) {
                ArrayList<Order> sorted=new ArrayList<>(offers[g.ordinal()]);
                sorted.sort(Comparator.comparingLong(o->o.seq));
                for(Order o:sorted) {
                    long[] fields={g.ordinal(),o.owner.id,o.price,o.quantity,o.seq};
                    for(long field:fields) result=(result^field)*0x100000001b3L;
                }
            }
            return result;
        }
    }
    static final class Economy implements CombatPrototype.CombatEconomyHook {
        final Account[] accounts;
        final Market market=new Market();
        final int fighters, crafters, couriers;
        final long initialAdena, initialOre, initialShots;
        long lootAwarded, shotConsumed, shotCrafted, oreCrafted, craftingFees;
        long strategyReevaluations, travels, socialInteractions, snapshots, snapshotBytes;
        long marketNs, travelNs, socialNs, snapshotNs;
        Economy(int count,int fighters) {
            if(count<20||fighters<=0||fighters>=count)throw new IllegalArgumentException();
            this.fighters=fighters;
            int rest=count-fighters;
            crafters=rest/2;
            couriers=rest*3/10;
            accounts=new Account[count];
            long totalA=0,totalO=0,totalS=0;
            for(int i=0;i<count;i++) {
                Occupation job=i<fighters?Occupation.COMBAT:i<fighters+crafters?Occupation.CRAFTER:
                    i<fighters+crafters+couriers?Occupation.COURIER:Occupation.SOCIAL;
                Account a=accounts[i]=new Account(i,job);
                totalA+=a.adena;totalO+=a.ore;totalS+=a.shots;
            }
            initialAdena=totalA;initialOre=totalO;initialShots=totalS;
        }
        @Override public void onPlayerAction(int actorId,CombatPrototype.Skill skill,int at) {
            if(actorId>=fighters)return;
            Account a=accounts[actorId];
            if(a.shots>0) { a.shots--;shotConsumed++; }
            if(a.shots<2&&!a.supplyNeeded) { a.supplyNeeded=true;strategyReevaluations++; }
        }
        @Override public void onLootAward(int actorId,int at) {
            if(actorId>=fighters)throw new AssertionError("Loot from unknown combatant");
            accounts[actorId].ore++;
            lootAwarded++;
        }
        void marketStep(int at) {
            long started=System.nanoTime();
            // Fighters offer *awarded* loot. For the benchmark, the market abstracts location;
            // actual L2 trading requires explicit access/transport rules not implemented here.
            for(int i=0;i<fighters;i++) {
                Account a=accounts[i];
                if(a.ore>0)market.list(a,Good.ORE,a.ore,3+(i%3));
            }
            // Crafters buy real, scarce ore, convert it according to a synthetic recipe,
            // and sell the resulting consumables; crafting has an adena sink.
            for(int i=fighters;i<fighters+crafters;i++) {
                Account a=accounts[i];
                if(a.ore<4)market.buy(a,Good.ORE,8,5);
                int crafts=Math.min(2,a.ore/2);
                if(crafts>0) {
                    if(a.adena<crafts)throw new AssertionError("Craft fee unavailable");
                    a.ore-=crafts*2;
                    a.shots+=crafts*12;
                    a.adena-=crafts;
                    oreCrafted+=crafts*2;
                    shotCrafted+=crafts*12;
                    craftingFees+=crafts;
                }
                if(a.shots>10)market.list(a,Good.SHOT,Math.min(28,a.shots-10),2+(i%2));
            }
            for(int i=0;i<fighters;i++) {
                Account a=accounts[i];
                if(a.supplyNeeded) {
                    int supplied=market.buy(a,Good.SHOT,6,4);
                    if(supplied>0) {a.supplyNeeded=false;strategyReevaluations++;}
                }
            }
            marketNs+=System.nanoTime()-started;
        }
        void travelStep(int at) {
            long started=System.nanoTime();
            for(int i=fighters+crafters;i<fighters+crafters+couriers;i++) {
                Account a=accounts[i];
                int delta=a.destination-a.x;
                if(delta!=0) {a.x+=Integer.signum(delta)*Math.min(160,Math.abs(delta));travels++;}
                if(a.x==a.destination) {
                    if(!a.inTransit) {
                        int got=market.buy(a,Good.SHOT,3,4);
                        if(got>0) {a.inTransit=true; a.destination=900+(i%300);strategyReevaluations++;}
                    } else {
                        // Courier does not duplicate bought stock; relists the very same goods.
                        if(a.shots>0)market.list(a,Good.SHOT,a.shots,4);
                        a.inTransit=false;a.destination=0;strategyReevaluations++;
                    }
                }
            }
            travelNs+=System.nanoTime()-started;
        }
        void socialStep(int at) {
            long started=System.nanoTime();
            for(int i=fighters+crafters+couriers;i<accounts.length;i++) {
                Account a=accounts[i];
                // A synthetic accepted local invitation; actual channels/rights remain out of scope.
                int newParty=1+(i/5);
                if(a.socialParty!=newParty) {a.socialParty=newParty;strategyReevaluations++;}
                socialInteractions++;
            }
            socialNs+=System.nanoTime()-started;
        }
        long accountDigest() {
            long h=0xcbf29ce484222325L;
            for(Account a:accounts) {
                long[] fields={a.id,a.adena,a.ore,a.shots,a.x,a.y,a.destination,a.socialParty,
                    a.supplyNeeded?1:0,a.inTransit?1:0,a.occupation.ordinal()};
                for(long field:fields)h=(h^field)*0x100000001b3L;
            }
            return (h^market.digest())*0x100000001b3L;
        }
        void checkpointStep() {
            long started=System.nanoTime();
            // Snapshot of account/market-state fingerprint only, not durable storage or restart support.
            accountDigest();snapshots++;snapshotBytes+=accounts.length*48L;
            snapshotNs+=System.nanoTime()-started;
        }
        void assertConservation() {
            long a=0,o=market.escrow(Good.ORE),s=market.escrow(Good.SHOT);
            for(Account ac:accounts) {
                if(ac.adena<0||ac.ore<0||ac.shots<0)throw new AssertionError("Negative balance");
                a+=ac.adena;o+=ac.ore;s+=ac.shots;
            }
            if(a+craftingFees!=initialAdena)throw new AssertionError("Adena conservation: "+a+" + "+craftingFees+" != "+initialAdena);
            if(o+oreCrafted!=initialOre+lootAwarded)throw new AssertionError("Ore conservation");
            if(s+shotConsumed!=initialShots+shotCrafted)throw new AssertionError("Shot conservation");
        }
    }
    record Result(String scenario,String mode,int accounts,int combatants,int entities,int seconds,
                  long elapsedNs,long combatNs,long marketNs,long travelNs,long socialNs,long snapshotNs,
                  long processed,long decisions,long events,long loot,long trades,long crafted,long shotsUsed,
                  long movement,long social,long economyDigest,long combatDigest) {
        boolean sameState(Result other) {
            return economyDigest==other.economyDigest&&combatDigest==other.combatDigest&&
                 loot==other.loot&&trades==other.trades&&crafted==other.crafted&&shotsUsed==other.shotsUsed&&
                 movement==other.movement&&social==other.social&&processed==other.processed;
        }
    }
    static Result run(int nAccounts,int nCombat,int seconds,long seed,CombatPrototype.Scenario scenario,CombatPrototype.Mode mode) {
        Economy e=new Economy(nAccounts,nCombat);
        CombatPrototype.World battle=new CombatPrototype.World(scenario,mode,CombatPrototype.Search.SCAN,nCombat,seconds*1000,seed);
        battle.economyHook=e;
        long started=System.nanoTime(),combatNs=0;
        for(int t=1000;t<=seconds*1000;t+=1000) {
            long ct=System.nanoTime(); battle.advanceTo(t); combatNs+=System.nanoTime()-ct;
            e.marketStep(t);e.travelStep(t);e.socialStep(t);
            e.checkpointStep();e.assertConservation();
        }
        CombatPrototype.Result combat=battle.run();
        e.assertConservation();
        return new Result(scenario.name(),mode.name(),nAccounts,nCombat,battle.actors.length,seconds,
                System.nanoTime()-started,combatNs,e.marketNs,e.travelNs,e.socialNs,e.snapshotNs,
                battle.processed,e.strategyReevaluations,battle.combatActions,e.lootAwarded,
                e.market.trades,e.shotCrafted,e.shotConsumed,e.travels,e.socialInteractions,
                e.accountDigest(),combat.digest());
    }
    static void testMarketEscrow() {
        Account seller=new Account(0,Occupation.CRAFTER);
        Account buyerA=new Account(1,Occupation.COMBAT);
        Account buyerB=new Account(2,Occupation.COMBAT);
        seller.ore=3;
        long initialA=seller.adena+buyerA.adena+buyerB.adena;
        Market m=new Market();
        m.list(seller,Good.ORE,3,5);
        if(seller.ore!=0||m.escrow(Good.ORE)!=3)throw new AssertionError("Escrow not funded");
        if(m.buy(buyerA,Good.ORE,2,4)!=0)throw new AssertionError("Exceeded price cap");
        if(m.buy(buyerA,Good.ORE,2,5)!=2||m.buy(buyerB,Good.ORE,2,5)!=1)
            throw new AssertionError("Double-sold an exclusive order");
        if(m.buy(buyerB,Good.ORE,1,5)!=0||m.escrow(Good.ORE)!=0||buyerA.ore!=2||buyerB.ore!=1)
            throw new AssertionError("Exhausted order was not removed");
        if(initialA!=seller.adena+buyerA.adena+buyerB.adena)throw new AssertionError("Adena minted");
        boolean rejected=false;
        try {m.list(seller,Good.ORE,1,5);}catch(IllegalArgumentException expected){rejected=true;}
        if(!rejected)throw new AssertionError("Listing without available goods");
    }
    static void tests() {
        testMarketEscrow();
        for(int s:new int[]{4,8})for(long seed:new long[]{1,42,12345}) {
            Result a=run(150,100,s,seed,CombatPrototype.Scenario.PVE,CombatPrototype.Mode.DETAIL);
            Result b=run(150,100,s,seed,CombatPrototype.Scenario.PVE,CombatPrototype.Mode.BATCH);
            if(!a.sameState(b))throw new AssertionError("Different world state: "+a+" vs "+b);
            if(a.loot==0||a.trades==0||a.crafted==0||a.shotsUsed==0)
                throw new AssertionError("Not exercising whole economy: "+a);
        }
        // No goods/adana duplication on purchase, resale and crafting; test with many participants.
        Result a=run(1400,1120,8,77,CombatPrototype.Scenario.PVE,CombatPrototype.Mode.DETAIL);
        Result b=run(1400,1120,8,77,CombatPrototype.Scenario.PVE,CombatPrototype.Mode.BATCH);
        if(!a.sameState(b))throw new AssertionError("Mismatch at scale");
        System.out.println("PASS interleaved combat/economy invariants and exact DETAIL/BATCH outcomes");
    }
    public static void main(String[] args) {
        if(Arrays.asList(args).contains("--test")){tests();return;}
        int n=7000,nCombat=5600,seconds=8,repeats=2;
        CombatPrototype.Scenario scenario=CombatPrototype.Scenario.PVE;
        for(int i=0;i<args.length;i++){
            String k=args[i];if(i+1>=args.length)throw new IllegalArgumentException("Missing value for "+k);
            switch(k){
                case "--accounts"->n=Integer.parseInt(args[++i]);
                case "--combat"->nCombat=Integer.parseInt(args[++i]);
                case "--seconds"->seconds=Integer.parseInt(args[++i]);
                case "--repeats"->repeats=Integer.parseInt(args[++i]);
                case "--scenario"->scenario=CombatPrototype.Scenario.valueOf(args[++i].toUpperCase(Locale.ROOT));
                default->throw new IllegalArgumentException("Unknown arg "+k);
            }
        }
        if(seconds>120||seconds<2||repeats<1)throw new IllegalArgumentException();
        System.out.println("scenario,mode,accounts,combat_characters,combat_entities,seconds,elapsed_ms,combat_ms,market_ms,travel_ms,social_ms,snapshot_ms,events,decisions,actions,loot,trade_matches,shots_crafted,shots_used,courier_moves,social_events,economy_digest,combat_digest");
        for(int repeat=0;repeat<repeats;repeat++){
            Result a=run(n,nCombat,seconds,42,scenario,CombatPrototype.Mode.DETAIL);
            Result b=run(n,nCombat,seconds,42,scenario,CombatPrototype.Mode.BATCH);
            if(!a.sameState(b))throw new AssertionError("DETAIL != BATCH");
            for(Result r:new Result[]{a,b}){
                System.out.printf(Locale.ROOT,"%s,%s,%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%016x,%016x%n",
                    r.scenario(),r.mode(),r.accounts(),r.combatants(),r.entities(),r.seconds(),
                    r.elapsedNs()/1e6,r.combatNs()/1e6,r.marketNs()/1e6,r.travelNs()/1e6,r.socialNs()/1e6,r.snapshotNs()/1e6,
                    r.processed(),r.decisions(),r.events(),r.loot(),r.trades(),r.crafted(),r.shotsUsed(),
                    r.movement(),r.social(),r.economyDigest(),r.combatDigest());
            }
        }
    }
}
