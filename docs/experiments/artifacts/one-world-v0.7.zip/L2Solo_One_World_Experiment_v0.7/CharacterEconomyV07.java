import java.util.*;

/** V0.7 experimental ownership ledger. Synchronous/atomic in this single-thread runner, not a concurrent production store. */
public final class CharacterEconomyV07 {
    enum Good { ORE, SHOT }
    static final class Inventory {
        long adena;
        int ore, shots;
        int get(Good good) { return good == Good.ORE ? ore : shots; }
        void change(Good good, int delta) {
            if (good == Good.ORE) ore = Math.addExact(ore, delta);
            else shots = Math.addExact(shots, delta);
            if (ore < 0 || shots < 0 || adena < 0) throw new AssertionError("Negative inventory");
        }
        long digest() { return (adena * 31 + ore) * 31 + shots; }
    }
    static final class Ledger {
        final int[] owner;
        final Inventory[] character;
        final Inventory[] warehouse; // one Account Warehouse per Account, not a CP Warehouse
        final Market[] markets;
        long warehouseTransfers;
        Ledger(int accounts, int characters, int regions) {
            owner = new int[characters];
            character = new Inventory[characters];
            warehouse = new Inventory[accounts];
            markets = new Market[regions];
            for (int a = 0; a < accounts; a++) warehouse[a] = new Inventory();
            for (int c = 0; c < characters; c++) {
                owner[c] = c % accounts;
                character[c] = new Inventory();
            }
            for (int i = 0; i < regions; i++) markets[i] = new Market(this);
        }
        /** Transfer requires the caller to establish warehouse-NPC access; no implicit cross-character sharing. */
        int throughWarehouse(int cid, Good good, int qty, boolean deposit, boolean nearNpc) {
            if (!nearNpc) throw new IllegalStateException("Warehouse NPC proximity required");
            if (qty < 0) throw new IllegalArgumentException("Negative quantity");
            Inventory from = deposit ? character[cid] : warehouse[owner[cid]];
            Inventory to = deposit ? warehouse[owner[cid]] : character[cid];
            int moved = Math.min(qty, from.get(good));
            from.change(good, -moved);
            to.change(good, moved);
            if (moved > 0) warehouseTransfers++;
            return moved;
        }
        long throughWarehouseAdena(int cid,long amount,boolean deposit,boolean nearNpc) {
            if(!nearNpc)throw new IllegalStateException("Warehouse NPC proximity required");
            if(amount<0)throw new IllegalArgumentException("Negative adena transfer");
            Inventory from=deposit?character[cid]:warehouse[owner[cid]];
            Inventory to=deposit?warehouse[owner[cid]]:character[cid];
            long moved=Math.min(amount,from.adena);
            from.adena-=moved;to.adena=Math.addExact(to.adena,moved);
            if(moved>0)warehouseTransfers++;
            return moved;
        }
        long digest() {
            long h = 0xcbf29ce484222325L;
            for (int c = 0; c < character.length; c++) {
                h = (h ^ owner[c]) * 0x100000001b3L;
                h = (h ^ character[c].digest()) * 0x100000001b3L;
            }
            for (Inventory w : warehouse) h = (h ^ w.digest()) * 0x100000001b3L;
            for (Market m : markets) h = (h ^ m.digest()) * 0x100000001b3L;
            return h;
        }
    }
    static final class Order {
        final int seller, price;
        final long seq;
        int remaining;
        Order(int seller, int price, int qty, long seq) {
            this.seller = seller; this.price = price; this.remaining = qty; this.seq = seq;
        }
    }
    static final class Market {
        final Ledger ledger;
        @SuppressWarnings("unchecked")
        final PriorityQueue<Order>[] offers = new PriorityQueue[] {
            new PriorityQueue<>(Comparator.<Order>comparingInt(o -> o.price).thenComparingLong(o -> o.seq)),
            new PriorityQueue<>(Comparator.<Order>comparingInt(o -> o.price).thenComparingLong(o -> o.seq))
        };
        long nextSeq, matches;
        Market(Ledger ledger) { this.ledger = ledger; }
        void list(int seller, Good good, int qty, int price) {
            Inventory inv = ledger.character[seller];
            if (qty <= 0 || price <= 0 || inv.get(good) < qty) throw new IllegalArgumentException("Unfunded listing");
            inv.change(good, -qty); // exclusively in order escrow until filled
            offers[good.ordinal()].add(new Order(seller, price, qty, nextSeq++));
        }
        int buy(int buyer, Good good, int wanted, int maxPrice) {
            if (wanted <= 0 || maxPrice <= 0) throw new IllegalArgumentException();
            Inventory buyerInv = ledger.character[buyer];
            PriorityQueue<Order> q = offers[good.ordinal()];
            int filled = 0;
            ArrayList<Order> selfOffers = null;
            try {
                while (filled < wanted && !q.isEmpty()) {
                    Order order = q.peek();
                    if (order.price > maxPrice || buyerInv.adena < order.price) break;
                    if (ledger.owner[order.seller] == ledger.owner[buyer]) {
                        if(selfOffers==null)selfOffers=new ArrayList<>();
                        selfOffers.add(q.poll());
                        continue; // do not block other sellers behind own order
                    }
                    int take = (int)Math.min(Math.min((long)(wanted - filled), (long)order.remaining), buyerInv.adena / order.price);
                    if (take == 0) break;
                    long paid = (long)take * order.price;
                    buyerInv.adena -= paid;
                    ledger.character[order.seller].adena += paid;
                    buyerInv.change(good, take);
                    order.remaining -= take;
                    if (order.remaining == 0) q.poll();
                    filled += take; matches++;
                }
            } finally {
                if(selfOffers!=null)q.addAll(selfOffers);
            }
            return filled;
        }
        long escrow(Good good) {
            long total = 0;
            for (Order o : offers[good.ordinal()]) total += o.remaining;
            return total;
        }
        long digest() {
            long h = 0xcbf29ce484222325L;
            for (Good good : Good.values()) {
                ArrayList<Order> sorted = new ArrayList<>(offers[good.ordinal()]);
                sorted.sort(Comparator.comparingLong(o -> o.seq));
                for (Order o : sorted) {
                    for (long v : new long[]{good.ordinal(), o.seller, o.price, o.remaining, o.seq})
                        h = (h ^ v) * 0x100000001b3L;
                }
            }
            return h;
        }
    }

    static void testLedger() {
        Ledger l = new Ledger(2, 4, 1); // characters 0/2 belong to Account 0; 1/3 to Account 1
        l.character[0].ore = 10;
        l.character[1].adena = 100;
        if (l.character[2].ore != 0) throw new AssertionError("Two Characters share inventory");
        try {
            l.throughWarehouse(0, Good.ORE, 5, true, false);
            throw new AssertionError("Remote warehouse operation accepted");
        } catch (IllegalStateException expected) { }
        l.throughWarehouse(0, Good.ORE, 5, true, true);
        if (l.character[2].ore != 0 || l.warehouse[0].ore != 5) throw new AssertionError("Warehouse leaked inventory");
        l.throughWarehouse(2, Good.ORE, 3, false, true);
        l.character[0].adena=12;
        l.throughWarehouseAdena(0,7,true,true);
        l.throughWarehouseAdena(2,5,false,true);
        if(l.character[0].adena!=5||l.character[2].adena!=5||l.warehouse[0].adena!=2)
            throw new AssertionError("Adena warehouse transfer");
        if (l.character[2].ore != 3 || l.warehouse[0].ore != 2) throw new AssertionError("Account warehouse withdrawal");
        l.markets[0].list(0, Good.ORE, 5, 4);
        if (l.character[0].ore != 0 || l.markets[0].escrow(Good.ORE) != 5) throw new AssertionError("Listings mint goods");
        if (l.markets[0].buy(1, Good.ORE, 2, 4) != 2 || l.markets[0].buy(1, Good.ORE, 5, 4) != 3)
            throw new AssertionError("Trade matching");
        if (l.markets[0].buy(1, Good.ORE, 1, 4) != 0 || l.character[1].ore != 5
                || l.character[0].adena != 25 || l.character[1].adena != 80 || l.warehouse[0].ore != 2)
            throw new AssertionError("Item/adenа conservation");
        l.character[0].ore=1;
        l.markets[0].list(0,Good.ORE,1,1);
        l.markets[0].list(1,Good.ORE,2,3);
        if(l.markets[0].buy(2,Good.ORE,1,4)!=1 || l.character[2].ore!=4)
            throw new AssertionError("Own Account escrow incorrectly blocks other sellers");
        if(l.markets[0].escrow(Good.ORE)!=2)
            throw new AssertionError("Self order bypass lost escrow");
        try {
            l.markets[0].list(0, Good.SHOT, 1, 3);
            throw new AssertionError("Unfunded listing allowed");
        } catch (IllegalArgumentException expected) { }
    }
}
