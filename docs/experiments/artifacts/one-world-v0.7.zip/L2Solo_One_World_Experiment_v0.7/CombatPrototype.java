import java.util.*;

/**
 * L2Solo CPU combat experiment v0.3, Java 21, no external dependencies.
 * Identical game rules are executed with two schedulers and two target-query strategies.
 * All times are integer milliseconds. This is NOT a complete L2 combat model.
 */
public final class CombatPrototype {
    enum Scenario { PVE, SKIRMISH, SIEGE, DENSE_SIEGE, MIXED_WORLD }
    enum Mode { DETAIL, BATCH }
    enum Search { SCAN, GRID }
    enum Type { ACTION, MOVE, RESPAWN }
    enum Skill { AUTO, NUKE, AOE_DAMAGE, CONE_DAMAGE, PARTY_HEAL, MASS_HEAL, STUN, DASH }
    enum Role { FIGHTER, ARCHER, MAGE, HEALER, CONTROLLER, NPC }

    static final int CELL = 180;
    static final int ATTACK_RANGE = 125;
    static final int SEEK_RANGE = 950;
    static final int NUKE_RANGE = 480;
    static final int STUN_RANGE = 275;
    static final int CONE_RADIUS = 220;
    static final int DASH_RANGE = 600;
    static final int DASH_STEP = 260;
    static final int AOE_RADIUS = 180;
    static final int HEAL_RADIUS = 300;
    static final int MOVE_PERIOD = 700;
    static final int MOVE_STEP = 110;
    static final int MAX_AOE_TARGETS = 6;
    static final int MAX_PARTY_HEAL_TARGETS = 9;
    static final int MAX_MASS_HEAL_TARGETS = 32;
    static final int SPELL_COST = 35;
    static final int[] MP_COST = {0, 25, 45, 40, 35, 55, 25, 20};
    static final int[] SKILL_COOLDOWN = {0, 1600, 2800, 2400, 2100, 4600, 4200, 5000};
    static final int STUN_DURATION = 1300;
    static final int RESPAWN_PLAYER = 4000;
    static final int RESPAWN_NPC = 2200;

    record Event(int timeMs, long seq, int actorId, int version, Type type) {}

    interface Scheduler {
        void add(Event e);
        Event take();
        Event peek();
        boolean hasNext();
    }

    static final class DetailedScheduler implements Scheduler {
        final PriorityQueue<Event> q = new PriorityQueue<>(Comparator
                .comparingInt(Event::timeMs).thenComparingLong(Event::seq));
        public void add(Event e) { q.add(e); }
        public Event take() { return q.remove(); }
        public Event peek() { return q.peek(); }
        public boolean hasNext() { return !q.isEmpty(); }
    }

    /** A bounded 1-ms calendar for the benchmark only, not a perpetual-world design. */
    static final class BucketScheduler implements Scheduler {
        final ArrayDeque<Event>[] buckets;
        int cursor, remaining;
        @SuppressWarnings("unchecked")
        BucketScheduler(int durationMs) { buckets = (ArrayDeque<Event>[]) new ArrayDeque<?>[durationMs + 1]; }
        public void add(Event e) {
            if (e.timeMs < cursor || e.timeMs >= buckets.length) throw new IllegalStateException("Out of bucket time range");
            ArrayDeque<Event> b = buckets[e.timeMs];
            if (b == null) buckets[e.timeMs] = b = new ArrayDeque<>();
            b.addLast(e);
            remaining++;
        }
        public Event take() {
            while (cursor < buckets.length) {
                ArrayDeque<Event> b = buckets[cursor];
                if (b != null && !b.isEmpty()) { remaining--; return b.removeFirst(); }
                cursor++;
            }
            throw new NoSuchElementException();
        }
        public Event peek() {
            int i = cursor;
            while (i < buckets.length) {
                ArrayDeque<Event> b = buckets[i];
                if (b != null && !b.isEmpty()) return b.peekFirst();
                i++;
            }
            return null;
        }
        public boolean hasNext() { return remaining > 0; }
    }

    static long mix(long z) {
        z = (z ^ z >>> 30) * 0xbf58476d1ce4e5b9L;
        z = (z ^ z >>> 27) * 0x94d049bb133111ebL;
        return z ^ z >>> 31;
    }

    static final class Actor {
        final int id, team, group, party, maxHp, maxMp, attack, cooldownMs;
        final boolean npc, boss;
        final Skill speciality;
        final Role role;
        final int[] skillReadyAt = new int[Skill.values().length];
        final int homeX, homeY;
        int hp, mp, lastMpAt, version, x, y;
        int stunnedUntil, lastDecisionAt;
        boolean combatActive = true; // Player Activity, independent from whether Character exists in the world.
        int usedNukes, usedCones, usedStuns, usedDashes, tacticalChoices, kites, chases, supportMoves;
        int deaths, kills, xp, loot, attacks, spells, damageDone, healsDone;
        long rng;

        Actor(int id, int team, int group, int party, boolean npc, int x, int y, long seed) {
            this(id, team, group, party, npc, false, x, y, seed);
        }
        Actor(int id, int team, int group, int party, boolean npc, boolean boss, int x, int y, long seed) {
            this.id = id;
            this.team = team;
            this.group = group;
            this.party = party;
            this.npc = npc; this.boss = boss;
            this.x = this.homeX = x;
            this.y = this.homeY = y;
            this.maxHp = boss ? 24000 : npc ? 650 : 1200;
            this.maxMp = npc ? 0 : 220;
            this.hp = maxHp;
            this.mp = maxMp;
            this.attack = boss ? 185 : npc ? 43 + id % 17 : 74 + id % 21;
            this.cooldownMs = boss ? 1750 : npc ? 1050 + id % 200 : 780 + id % 270;
            // Stress-test skill distribution, NOT a game-class design.
            this.role = npc ? Role.NPC : id % 17 == 0 ? Role.HEALER
                    : id % 13 == 0 ? Role.CONTROLLER : id % 7 == 0 ? Role.MAGE
                    : id % 5 == 0 ? Role.ARCHER : Role.FIGHTER;
            this.speciality = role == Role.HEALER ? Skill.MASS_HEAL
                    : role == Role.MAGE ? Skill.AOE_DAMAGE
                    : role == Role.CONTROLLER ? Skill.STUN : Skill.AUTO;
            rng = mix(seed + 0x9e3779b97f4a7c15L * (id + 1L));
            if (rng == 0) rng = 1;
        }
        int roll(int bound) {
            rng ^= rng >>> 12;
            rng ^= rng << 25;
            rng ^= rng >>> 27;
            return (int) Long.remainderUnsigned(rng * 2685821657736338717L, bound);
        }
    }

    static final class Group {
        final int[][] teams = {new int[0], new int[0]};
        Group(List<Integer> a, List<Integer> b) {
            teams[0] = a.stream().mapToInt(Integer::intValue).toArray();
            teams[1] = b.stream().mapToInt(Integer::intValue).toArray();
        }
    }

    /** No geometry/LOS or physical collision. Grid only accelerates proximity queries. */
    static final class SpatialGrid {
        final HashMap<Long, HashSet<Integer>> cells = new HashMap<>();
        static int cell(int v) { return Math.floorDiv(v, CELL); }
        static long key(int x, int y) { return ((long) x << 32) | (y & 0xffffffffL); }
        void add(Actor a) { cells.computeIfAbsent(key(cell(a.x), cell(a.y)), k -> new HashSet<>()).add(a.id); }
        void moved(Actor a, int oldX, int oldY) {
            long previous = key(cell(oldX), cell(oldY));
            long next = key(cell(a.x), cell(a.y));
            if (previous == next) return;
            HashSet<Integer> from = cells.get(previous);
            if (from == null || !from.remove(a.id)) throw new IllegalStateException("Lost spatial membership " + a.id);
            if (from.isEmpty()) cells.remove(previous);
            cells.computeIfAbsent(next, k -> new HashSet<>()).add(a.id);
        }
    }

    /** Optional v0.4 adapter; identical combat rules with/without economic side effects. */
    interface CombatEconomyHook {
        void onPlayerAction(int actorId, Skill skill, int at);
        void onLootAward(int actorId, int at);
        default void onPlayerAttacked(int actorId, int at) {}
    }

    static final class World {
        CombatEconomyHook economyHook;
        boolean profiling;
        int profilePhase; // 1 tactical action, 2 movement
        long actionNs, movementNs, actionQueryNs, moveQueryNs, otherQueryNs, schedulerNs;
        long queryCalls, actionCalls, moveCalls;
        final Scenario scenario;
        final Search search;
        final int durationMs;
        final Actor[] actors;
        final Group[] groups;
        final Scheduler scheduler;
        final SpatialGrid grid;
        int now = -1;
        long sequence, processed, stale, combatActions, movementEvents, queryChecks;
        long attacks, casts, damageEffects, healEffects, aoeCasts, partyHeals, massHeals, deaths, loot;
        long aoeTargetsHit, partyTargetsHealed, massTargetsHealed;
        long nukes, cones, stuns, dashes, tacticalChoices, chaseMoves, kiteMoves, supportMoves;

        World(Scenario scenario, Mode mode, Search search, int characters, int durationMs, long seed) {
            if (characters < 2 || durationMs < 1000 || durationMs > 120_000)
                throw new IllegalArgumentException("Need 2+ characters; 1-120 seconds");
            if (scenario == Scenario.MIXED_WORLD && search != Search.GRID)
                throw new IllegalArgumentException("Mixed world uses global spatial queries; GRID required for now");
            this.scenario = scenario;
            this.search = search;
            this.durationMs = durationMs;
            this.scheduler = mode == Mode.DETAIL ? new DetailedScheduler() : new BucketScheduler(durationMs);
            this.grid = search == Search.GRID ? new SpatialGrid() : null;
            if (scenario == Scenario.MIXED_WORLD) {
                MixedLayout mixed = createMixed(characters, seed);
                actors = mixed.actors;
                groups = mixed.groups;
                if (grid != null) for (Actor a : actors) grid.add(a);
                for (Actor a : actors) {
                    schedule(a, Type.ACTION, a.id % 67, a.version);
                    schedule(a, Type.MOVE, 350 + a.id % 170, a.version);
                }
                return;
            }
            int groupSize = scenario == Scenario.PVE ? 1 : scenario == Scenario.SKIRMISH ? 16 : characters;
            int groupCount = (characters + groupSize - 1) / groupSize;
            actors = new Actor[scenario == Scenario.PVE ? 2 * characters : characters];
            groups = new Group[groupCount];
            for (int g = 0; g < groupCount; g++) {
                int start = g * groupSize;
                int end = Math.min(characters, start + groupSize);
                int mid = scenario == Scenario.PVE ? end : start + (end - start + 1) / 2;
                List<Integer> left = new ArrayList<>(), right = new ArrayList<>();
                int baseX = (g % 110) * 1450;
                int baseY = (g / 110) * 1450;
                if (scenario == Scenario.SIEGE || scenario == Scenario.DENSE_SIEGE) {
                    baseX = 0; baseY = 0;
                }
                for (int i = start; i < end; i++) {
                    int team = i < mid ? 0 : 1;
                    int radius = scenario == Scenario.DENSE_SIEGE ? 650 : scenario == Scenario.SIEGE ? 1900 : 90;
                    int x = baseX + Math.floorMod((int) mix(seed + i * 71L + 17), radius * 2 + 1) - radius;
                    int y = baseY + Math.floorMod((int) mix(seed + i * 103L + 43), radius * 2 + 1) - radius;
                    int party = scenario == Scenario.PVE ? i : (team == 0 ? (i - start) / 9 : (i - mid) / 9);
                    actors[i] = new Actor(i, team, g, party, false, x, y, seed);
                    (team == 0 ? left : right).add(i);
                }
                if (scenario == Scenario.PVE) {
                    for (int i = start; i < end; i++) {
                        int id = characters + i;
                        Actor character = actors[i];
                        actors[id] = new Actor(id, 1, g, -1, true, character.x + 45, character.y + 25, seed);
                        right.add(id);
                    }
                }
                groups[g] = new Group(left, right);
            }
            if (grid != null) for (Actor a : actors) grid.add(a);
            for (Actor a : actors) {
                schedule(a, Type.ACTION, a.id % 67, a.version);
                schedule(a, Type.MOVE, 350 + a.id % 170, a.version);
            }
        }

        /** One authoritative combat state: PvE, PvP, raids and siege share time and spatial queries. */
        static final class MixedLayout {
            final Actor[] actors;
            final Group[] groups;
            MixedLayout(Actor[] actors, Group[] groups) {this.actors=actors;this.groups=groups;}
        }
        static MixedLayout createMixed(int n, long seed) {
            // Counts are a synthetic load profile. Every instance belongs to the same World.
            int pve = n * 45 / 100;
            int skirmish = n * 20 / 100;
            int raid = n * 15 / 100;
            int siege = n - pve - skirmish - raid;
            int groupId = 0, npcId = n;
            ArrayList<Actor> members = new ArrayList<>();
            ArrayList<Group> groups = new ArrayList<>();
            // PvE groups are small clusters in one open region, not separate simulations.
            for (int i = 0; i < pve; i++) {
                int gx = (i % 80) * 190;
                int gy = (i / 80) * 190;
                int x = gx + (int)Math.floorMod(mix(seed + i * 29L), 77) - 38;
                int y = gy + (int)Math.floorMod(mix(seed + i * 47L), 77) - 38;
                members.add(new Actor(i, 0, groupId, i, false, x, y, seed));
                members.add(new Actor(npcId, 1, groupId, -1, true, x + 45, y + 25, seed));
                groups.add(new Group(List.of(i),List.of(npcId)));
                npcId++; groupId++;
            }
            // Separate skirmishes occupy a continuous area of this same coordinate space.
            for(int start=pve;start<pve+skirmish;start+=16) {
                int end=Math.min(pve+skirmish,start+16),mid=start+(end-start+1)/2;
                int patch=(start-pve)/16;
                int cx=22000+(patch%12)*500, cy=(patch/12)*500;
                ArrayList<Integer> left=new ArrayList<>(),right=new ArrayList<>();
                for(int i=start;i<end;i++) {
                    int team=i<mid?0:1;
                    int x=cx+(int)Math.floorMod(mix(seed+i*71L),261)-130;
                    int y=cy+(int)Math.floorMod(mix(seed+i*107L),261)-130;
                    int party=groupId*1000+(team==0?(i-start)/9:(i-mid)/9);
                    members.add(new Actor(i,team,groupId,party,false,x,y,seed));
                    (team==0?left:right).add(i);
                }
                groups.add(new Group(left,right));groupId++;
            }
            // Raid encounters: many players share the same boss HP and loot eligibility.
            for(int start=pve+skirmish;start<pve+skirmish+raid;start+=42) {
                int end=Math.min(pve+skirmish+raid,start+42);
                int patch=(start-pve-skirmish)/42;
                int cx=43000+(patch%8)*1050,cy=(patch/8)*1050;
                ArrayList<Integer> left=new ArrayList<>();
                for(int i=start;i<end;i++) {
                    int x=cx+(int)Math.floorMod(mix(seed+i*73L),441)-220;
                    int y=cy+(int)Math.floorMod(mix(seed+i*103L),441)-220;
                    members.add(new Actor(i,0,groupId,groupId*1000+(i-start)/9,false,x,y,seed));
                    left.add(i);
                }
                members.add(new Actor(npcId,1,groupId,-1,true,true,cx,cy,seed));
                groups.add(new Group(left,List.of(npcId)));
                npcId++;groupId++;
            }
            // One large PvP siege with globally addressable units, not a separate world.
            ArrayList<Integer> left=new ArrayList<>(),right=new ArrayList<>();
            int start=n-siege,mid=start+(siege+1)/2;
            for(int i=start;i<n;i++) {
                int team=i<mid?0:1;
                int x=62000+(int)Math.floorMod(mix(seed+i*97L),1901)-950;
                int y=(int)Math.floorMod(mix(seed+i*103L),1901)-950;
                members.add(new Actor(i,team,groupId,groupId*1000+(team==0?(i-start)/9:(i-mid)/9),false,x,y,seed));
                (team==0?left:right).add(i);
            }
            groups.add(new Group(left,right));
            Actor[] all=new Actor[npcId];
            for(Actor a:members)all[a.id]=a;
            for(Actor a:all)if(a==null)throw new IllegalStateException("Missing actor in shared world");
            return new MixedLayout(all,groups.toArray(new Group[0]));
        }

        /** Change only execution intent. Character remains present/targetable in the shared world. */
        void setCombatActive(int actorId, boolean active, int at) {
            Actor a = actors[actorId];
            if (a.npc) throw new IllegalArgumentException("NPC activity is controlled by world logic");
            if (a.combatActive == active) return;
            a.combatActive = active;
            if (a.hp <= 0) return; // Keep pending respawn event valid.
            a.version++; // Cancel stale ACTION/MOVE events without changing identity/HP/inventory.
            if (active) {
                schedule(a, Type.ACTION, at + 1, a.version);
                schedule(a, Type.MOVE, at + 1 + a.id % 170, a.version);
            }
        }

        void schedule(Actor a, Type type, int time, int version) {
            if (time <= durationMs) scheduler.add(new Event(time, sequence++, a.id, version, type));
        }

        void regenMp(Actor a, int at) {
            if (a.npc || a.hp <= 0) return;
            int ticks = (at - a.lastMpAt) / 1000;
            if (ticks > 0) {
                a.mp = Math.min(a.maxMp, a.mp + ticks * 6);
                a.lastMpAt += ticks * 1000;
            }
        }

        static long dist2(int x1, int y1, int x2, int y2) {
            long dx = (long) x1 - x2, dy = (long) y1 - y2;
            return dx * dx + dy * dy;
        }

        /** Find candidates in radius. The stable id sorting ensures both lookup modes have identical decisions. */
        ArrayList<Actor> nearby(int x, int y, int radius, int group, int team, int party, boolean filterParty) {
            long started = profiling ? System.nanoTime() : 0L;
            ArrayList<Actor> candidates = new ArrayList<>();
            long r2 = (long) radius * radius;
            if (search == Search.SCAN) {
                int[] side = groups[group].teams[team];
                for (int id : side) {
                    queryChecks++;
                    Actor a = actors[id];
                    if (a.hp > 0 && (!filterParty || a.party == party)
                            && dist2(a.x, a.y, x, y) <= r2) candidates.add(a);
                }
            } else {
                int minX = SpatialGrid.cell(x - radius), maxX = SpatialGrid.cell(x + radius);
                int minY = SpatialGrid.cell(y - radius), maxY = SpatialGrid.cell(y + radius);
                for (int cx = minX; cx <= maxX; cx++) for (int cy = minY; cy <= maxY; cy++) {
                    HashSet<Integer> bucket = grid.cells.get(SpatialGrid.key(cx, cy));
                    if (bucket == null) continue;
                    for (int id : bucket) {
                        queryChecks++;
                        Actor a = actors[id];
                        if (a.hp > 0 && (scenario == Scenario.MIXED_WORLD || a.group == group) && a.team == team
                                && (!filterParty || a.party == party)
                                && dist2(a.x, a.y, x, y) <= r2) candidates.add(a);
                    }
                }
            }
            candidates.sort(Comparator.comparingLong((Actor a) -> dist2(a.x, a.y, x, y))
                    .thenComparingInt(a -> a.id));
            if (profiling) addQueryTime(System.nanoTime() - started);
            return candidates;
        }

        /** Nearest enemy needs no list allocation or full sort; ties resolve by stable actor ID. */
        Actor nearestEnemy(Actor seeker, int radius) {
            long started = profiling ? System.nanoTime() : 0L;
            long limit2 = (long) radius * radius;
            Actor best = null;
            long bestDist = Long.MAX_VALUE;
            if (search == Search.SCAN) {
                for (int id : groups[seeker.group].teams[1 - seeker.team]) {
                    queryChecks++;
                    Actor candidate = actors[id];
                    if (candidate.hp <= 0) continue;
                    long d = dist2(candidate.x, candidate.y, seeker.x, seeker.y);
                    if (d <= limit2 && (d < bestDist || (d == bestDist && (best == null || id < best.id)))) {
                        best = candidate; bestDist = d;
                    }
                }
            } else {
                int minX = SpatialGrid.cell(seeker.x - radius), maxX = SpatialGrid.cell(seeker.x + radius);
                int minY = SpatialGrid.cell(seeker.y - radius), maxY = SpatialGrid.cell(seeker.y + radius);
                for (int cx = minX; cx <= maxX; cx++) for (int cy = minY; cy <= maxY; cy++) {
                    HashSet<Integer> bucket = grid.cells.get(SpatialGrid.key(cx, cy));
                    if (bucket == null) continue;
                    for (int id : bucket) {
                        queryChecks++;
                        Actor candidate = actors[id];
                        if (candidate.hp <= 0 || (scenario != Scenario.MIXED_WORLD && candidate.group != seeker.group) || candidate.team == seeker.team) continue;
                        long d = dist2(candidate.x, candidate.y, seeker.x, seeker.y);
                        if (d <= limit2 && (d < bestDist || (d == bestDist && (best == null || id < best.id)))) {
                            best = candidate; bestDist = d;
                        }
                    }
                }
            }
            if (profiling) addQueryTime(System.nanoTime() - started);
            return best;
        }

        void addQueryTime(long ns) {
            queryCalls++;
            if (profilePhase == 1) actionQueryNs += ns;
            else if (profilePhase == 2) moveQueryNs += ns;
            else otherQueryNs += ns;
        }

        void damage(Actor source, Actor target, int amount, int at) {
            if (source.hp <= 0 || target.hp <= 0) return;
            int applied = Math.min(target.hp, Math.max(0, amount));
            if (applied == 0) return;
            target.hp -= applied;
            if (economyHook != null && !target.npc && !target.combatActive)
                economyHook.onPlayerAttacked(target.id, at);
            source.damageDone += applied;
            damageEffects++;
            if (target.hp == 0) {
                deaths++; target.deaths++; source.kills++; target.version++;
                if (target.npc && !source.npc) {
                    source.xp += 100;
                    if (source.roll(2) == 0) {
                        source.loot++; loot++;
                        if (economyHook != null) economyHook.onLootAward(source.id, at);
                    }
                }
                schedule(target, Type.RESPAWN, at + (target.npc ? RESPAWN_NPC : RESPAWN_PLAYER), target.version);
            }
        }

        int heal(Actor healer, Actor recipient, int amount) {
            if (healer.hp <= 0 || recipient.hp <= 0) return 0; // No heal resurrection in this model.
            int applied = Math.min(recipient.maxHp - recipient.hp, Math.max(0, amount));
            if (applied > 0) {
                recipient.hp += applied;
                healer.healsDone += applied;
                healEffects++;
            }
            return applied;
        }

        /** Skill is party-restricted or team-restricted. Both have range and explicit target caps. */
        int areaHeal(Actor healer, Skill kind) {
            if (kind != Skill.PARTY_HEAL && kind != Skill.MASS_HEAL) throw new IllegalArgumentException();
            ArrayList<Actor> candidates = nearby(healer.x, healer.y, HEAL_RADIUS, healer.group,
                    healer.team, healer.party, kind == Skill.PARTY_HEAL);
            int cap = kind == Skill.PARTY_HEAL ? MAX_PARTY_HEAL_TARGETS : MAX_MASS_HEAL_TARGETS;
            int count = 0;
            // Prefer most injured first; id breaks ties. Same order across SCAN and GRID.
            candidates.sort(Comparator.<Actor>comparingInt(a -> -(a.maxHp - a.hp)).thenComparingInt(a -> a.id));
            for (Actor recipient : candidates) {
                if (count >= cap) break;
                if (recipient.maxHp - recipient.hp < 60) continue;
                if (heal(healer, recipient, kind == Skill.PARTY_HEAL ? 155 : 115) > 0) count++;
            }
            if (count > 0) {
                if (kind == Skill.PARTY_HEAL) { partyHeals++; partyTargetsHealed += count; }
                else { massHeals++; massTargetsHealed += count; }
            }
            return count;
        }

        boolean canUse(Actor a, Skill skill, int at) {
            return !a.npc && a.mp >= MP_COST[skill.ordinal()] && at >= a.skillReadyAt[skill.ordinal()];
        }

        void payFor(Actor a, Skill skill, int at) {
            if (!canUse(a, skill, at)) throw new IllegalStateException("Skill on cooldown or insufficient mana");
            a.mp -= MP_COST[skill.ordinal()];
            a.skillReadyAt[skill.ordinal()] = at + SKILL_COOLDOWN[skill.ordinal()];
            a.spells++; casts++;
            if (economyHook != null) economyHook.onPlayerAction(a.id, skill, at);
        }

        /** An actual geometric cone: target must be ahead of the caster, not just close to it. */
        boolean insideCone(Actor caster, Actor aimed, Actor test) {
            long ax = (long) aimed.x - caster.x, ay = (long) aimed.y - caster.y;
            long bx = (long) test.x - caster.x, by = (long) test.y - caster.y;
            long dot = ax * bx + ay * by;
            if (dot <= 0) return false;
            long a2 = ax * ax + ay * ay;
            long b2 = bx * bx + by * by;
            // 90-degree full cone (half angle 45 degrees), avoids floating-point comparison.
            return b2 <= (long) CONE_RADIUS * CONE_RADIUS && 2 * dot * dot >= a2 * b2;
        }

        int coneDamage(Actor caster, Actor aim, int at) {
            ArrayList<Actor> enemies = nearby(caster.x, caster.y, CONE_RADIUS,
                    caster.group, 1 - caster.team, -1, false);
            int count = 0;
            for (Actor target : enemies) {
                if (count >= MAX_AOE_TARGETS) break;
                if (insideCone(caster, aim, target)) {
                    damage(caster, target, 62 + caster.roll(22), at);
                    aoeTargetsHit++; count++;
                }
            }
            return count;
        }

        /** Each tactical choice is local to the current occupation; not a Goal/Activity replan. */
        void performAction(Actor a, int at) {
            long started = profiling ? System.nanoTime() : 0L;
            if (profiling) { profilePhase = 1; actionCalls++; }
            if (a.hp <= 0) throw new IllegalStateException("Dead actor acting");
            regenMp(a, at);
            combatActions++;
            if (at < a.stunnedUntil) {
                schedule(a, Type.ACTION, Math.max(at + 1, a.stunnedUntil), a.version);
                if (profiling) { actionNs += System.nanoTime() - started; profilePhase = 0; }
                return;
            }
            a.tacticalChoices++; tacticalChoices++;
            int attackRange = a.role == Role.ARCHER ? NUKE_RANGE : ATTACK_RANGE;
            Actor nearest = nearestEnemy(a, SEEK_RANGE);
            boolean cast = false;

            if (a.role == Role.HEALER) {
                ArrayList<Actor> allies = nearby(a.x, a.y, HEAL_RADIUS, a.group, a.team, a.party, false);
                int injured = 0, partyInjured = 0;
                for (Actor ally : allies) if (ally.maxHp - ally.hp >= 60) {
                    injured++;
                    if (ally.party == a.party) partyInjured++;
                }
                if (injured >= 3 && canUse(a, Skill.MASS_HEAL, at)) {
                    if (areaHeal(a, Skill.MASS_HEAL) > 0) { payFor(a, Skill.MASS_HEAL, at); cast = true; }
                }
                if (!cast && partyInjured > 0 && canUse(a, Skill.PARTY_HEAL, at)) {
                    if (areaHeal(a, Skill.PARTY_HEAL) > 0) { payFor(a, Skill.PARTY_HEAL, at); cast = true; }
                }
                if (!cast && injured > 0 && canUse(a, Skill.MASS_HEAL, at)) {
                    if (areaHeal(a, Skill.MASS_HEAL) > 0) { payFor(a, Skill.MASS_HEAL, at); cast = true; }
                }
            }

            if (!cast && nearest != null) {
                long d2 = dist2(a.x, a.y, nearest.x, nearest.y);
                if (a.role == Role.FIGHTER && d2 > (long) ATTACK_RANGE * ATTACK_RANGE
                        && d2 <= (long) DASH_RANGE * DASH_RANGE && canUse(a, Skill.DASH, at)) {
                    payFor(a, Skill.DASH, at);
                    step(a, nearest.x, nearest.y, DASH_STEP);
                    a.usedDashes++; dashes++;
                    cast = true;
                } else if (a.role == Role.CONTROLLER && d2 <= (long) STUN_RANGE * STUN_RANGE
                        && nearest.stunnedUntil <= at && canUse(a, Skill.STUN, at)) {
                    payFor(a, Skill.STUN, at);
                    nearest.stunnedUntil = at + STUN_DURATION;
                    a.usedStuns++; stuns++;
                    cast = true;
                } else if (a.role == Role.MAGE && d2 <= (long) NUKE_RANGE * NUKE_RANGE
                        && canUse(a, Skill.AOE_DAMAGE, at)) {
                    ArrayList<Actor> affected = nearby(nearest.x, nearest.y, AOE_RADIUS,
                            a.group, 1 - a.team, -1, false);
                    if (affected.size() >= 2) {
                        payFor(a, Skill.AOE_DAMAGE, at); aoeCasts++;
                        int count = 0;
                        for (Actor enemy : affected) {
                            if (count >= MAX_AOE_TARGETS) break;
                            damage(a, enemy, 85 + a.roll(35), at);
                            aoeTargetsHit++; count++;
                        }
                        cast = true;
                    }
                }
                if (!cast && a.role == Role.FIGHTER && d2 <= (long) CONE_RADIUS * CONE_RADIUS
                        && canUse(a, Skill.CONE_DAMAGE, at)) {
                    ArrayList<Actor> nearbyEnemies = nearby(a.x, a.y, CONE_RADIUS,
                            a.group, 1 - a.team, -1, false);
                    int potential = 0;
                    for (Actor target : nearbyEnemies) if (insideCone(a, nearest, target)) potential++;
                    if (potential >= 2) {
                        payFor(a, Skill.CONE_DAMAGE, at);
                        coneDamage(a, nearest, at);
                        a.usedCones++; cones++;
                        cast = true;
                    }
                }
                if (!cast && (a.role == Role.MAGE || a.role == Role.CONTROLLER || a.role == Role.HEALER)
                        && d2 <= (long) NUKE_RANGE * NUKE_RANGE && canUse(a, Skill.NUKE, at)) {
                    payFor(a, Skill.NUKE, at);
                    damage(a, nearest, 105 + a.roll(26), at);
                    a.usedNukes++; nukes++;
                    cast = true;
                }
                if (!cast && d2 <= (long) attackRange * attackRange) {
                    a.attacks++; attacks++;
                    if (economyHook != null && !a.npc) economyHook.onPlayerAction(a.id, Skill.AUTO, at);
                    int hit = a.roll(100);
                    if (hit >= 5) {
                        int amount = a.attack + a.roll(20);
                        if (hit >= 90) amount *= 2;
                        damage(a, nearest, amount, at);
                    }
                }
            }
            schedule(a, Type.ACTION, at + a.cooldownMs, a.version);
            if (profiling) { actionNs += System.nanoTime() - started; profilePhase = 0; }
        }

        /** Move toward the target, staying within maxSpeed and maintaining the spatial index. */
        void step(Actor a, int tx, int ty, int maxSpeed) {
            int oldX = a.x, oldY = a.y;
            long dx = (long) tx - a.x, dy = (long) ty - a.y;
            double len = Math.sqrt(dx * dx + dy * dy);
            if (len > 0.0) {
                int move = Math.min(maxSpeed, (int) Math.ceil(len));
                a.x += (int) Math.round(dx * move / len);
                a.y += (int) Math.round(dy * move / len);
            }
            if (grid != null) grid.moved(a, oldX, oldY);
        }

        void move(Actor a, int at) {
            long started = profiling ? System.nanoTime() : 0L;
            if (profiling) { profilePhase = 2; moveCalls++; }
            if (at < a.stunnedUntil) {
                schedule(a, Type.MOVE, Math.max(at + 1, a.stunnedUntil), a.version);
                if (profiling) { movementNs += System.nanoTime() - started; profilePhase = 0; }
                return;
            }
            Actor enemy = nearestEnemy(a, SEEK_RANGE);
            Actor woundedAlly = null;
            if (a.role == Role.HEALER) {
                for (Actor ally : nearby(a.x, a.y, SEEK_RANGE, a.group, a.team, a.party, true)) {
                    if (ally.hp < ally.maxHp - 150) { woundedAlly = ally; break; }
                }
            }
            if (a.role == Role.HEALER && woundedAlly != null
                    && dist2(a.x, a.y, woundedAlly.x, woundedAlly.y) > (long) (HEAL_RADIUS - 40) * (HEAL_RADIUS - 40)) {
                step(a, woundedAlly.x, woundedAlly.y, MOVE_STEP);
                a.supportMoves++; supportMoves++;
            } else if (enemy != null) {
                long d2 = dist2(a.x, a.y, enemy.x, enemy.y);
                boolean ranged = a.role == Role.ARCHER || a.role == Role.MAGE
                        || a.role == Role.HEALER || a.role == Role.CONTROLLER;
                int ideal = ranged ? (a.role == Role.HEALER ? 390 : 330) : 85;
                if (ranged && d2 < (long) (ideal - 80) * (ideal - 80)) {
                    // Move away from danger; deterministic fallback for overlapping positions.
                    int tx = a.x + (a.x == enemy.x && a.y == enemy.y ? 100 : a.x - enemy.x);
                    int ty = a.y + (a.x == enemy.x && a.y == enemy.y ? 0 : a.y - enemy.y);
                    step(a, tx, ty, MOVE_STEP);
                    a.kites++; kiteMoves++;
                } else if (d2 > (long) (ideal + 50) * (ideal + 50)) {
                    step(a, enemy.x, enemy.y, MOVE_STEP);
                    a.chases++; chaseMoves++;
                }
            } else {
                // Limited idle patrol, not pathfinding; avoid claiming a realistic navigation model.
                int dx = a.roll(61) - 30, dy = a.roll(61) - 30;
                step(a, a.x + dx, a.y + dy, MOVE_STEP);
            }
            movementEvents++;
            schedule(a, Type.MOVE, at + MOVE_PERIOD, a.version);
            if (profiling) { movementNs += System.nanoTime() - started; profilePhase = 0; }
        }

        void execute(Event e) {
            if (e.timeMs < now) throw new IllegalStateException("Nonmonotonic time");
            now = e.timeMs; processed++;
            Actor a = actors[e.actorId];
            if (a.version != e.version) { stale++; return; }
            if (!a.npc && !a.combatActive && e.type != Type.RESPAWN) { stale++; return; }
            switch (e.type) {
                case ACTION -> performAction(a, now);
                case MOVE -> move(a, now);
                case RESPAWN -> {
                    if (a.hp != 0) throw new IllegalStateException("Double respawn");
                    a.hp = a.maxHp; a.mp = a.maxMp; a.lastMpAt = now; a.stunnedUntil = 0;
                    a.version++;
                    if (a.npc || a.combatActive) {
                        schedule(a, Type.ACTION, now + 1, a.version);
                        schedule(a, Type.MOVE, now + MOVE_PERIOD, a.version);
                    }
                }
            }
        }

        /** Process events only up to the shared world-time boundary. */
        void advanceTo(int boundaryMs) {
            if (boundaryMs > durationMs || boundaryMs < now)
                throw new IllegalArgumentException("Non-monotonic/out-of-range boundary");
            Event next;
            while ((next = scheduler.peek()) != null && next.timeMs <= boundaryMs) {
                long started = profiling ? System.nanoTime() : 0L;
                Event event = scheduler.take();
                if (profiling) schedulerNs += System.nanoTime() - started;
                execute(event);
            }
        }

        Result run() {
            long start = System.nanoTime();
            advanceTo(durationMs);
            for (Actor a : actors) regenMp(a, durationMs);
            long ns = System.nanoTime() - start;
            long hash = 0xcbf29ce484222325L;
            for (Actor a : actors) {
                if (a.hp < 0 || a.hp > a.maxHp || a.mp < 0 || a.mp > a.maxMp)
                    throw new IllegalStateException("HP/MP boundaries: actor=" + a.id);
                long[] fields = {a.id,a.x,a.y,a.hp,a.mp,a.lastMpAt,a.version,a.deaths,a.kills,
                        a.xp,a.loot,a.attacks,a.spells,a.damageDone,a.healsDone,a.rng,
                        a.stunnedUntil,a.usedNukes,a.usedCones,a.usedStuns,a.usedDashes,
                        a.tacticalChoices,a.kites,a.chases,a.supportMoves,a.combatActive ? 1 : 0};
                for (long v : fields) hash = (hash ^ v) * 0x100000001b3L;
                for (int v : a.skillReadyAt) hash = (hash ^ v) * 0x100000001b3L;
            }
            long[] totals = {processed,stale,combatActions,movementEvents,attacks,casts,damageEffects,healEffects,
                    aoeCasts,partyHeals,massHeals,aoeTargetsHit,partyTargetsHealed,massTargetsHealed,deaths,loot,
                    nukes,cones,stuns,dashes,tacticalChoices,chaseMoves,kiteMoves,supportMoves};
            for (long v : totals) hash = (hash ^ v) * 0x100000001b3L;
            return new Result(scenario, actors.length, durationMs, ns, hash,
                    processed,combatActions,movementEvents,queryChecks,damageEffects,healEffects,
                    aoeCasts,partyHeals,massHeals,partyTargetsHealed,massTargetsHealed,deaths,loot,
                    nukes,cones,stuns,dashes,tacticalChoices,chaseMoves,kiteMoves,supportMoves);
        }
    }

    record Result(Scenario scenario, int entities, int durationMs, long elapsedNs, long digest,
                  long events, long combatActions, long movements, long candidateChecks, long damageEffects,
                  long healEffects, long aoeCasts, long partyHeals, long massHeals,
                  long partyTargetsHealed, long massTargetsHealed, long deaths, long loot,
                  long nukes, long cones, long stuns, long dashes, long tacticalChoices,
                  long chaseMoves, long kiteMoves, long supportMoves) {
        boolean sameState(Result b) {
            return digest == b.digest && events == b.events && combatActions == b.combatActions
                    && movements == b.movements && damageEffects == b.damageEffects
                    && healEffects == b.healEffects && aoeCasts == b.aoeCasts
                    && partyHeals == b.partyHeals && massHeals == b.massHeals
                    && partyTargetsHealed == b.partyTargetsHealed && massTargetsHealed == b.massTargetsHealed
                    && deaths == b.deaths && loot == b.loot && nukes == b.nukes
                    && cones == b.cones && stuns == b.stuns && dashes == b.dashes
                    && tacticalChoices == b.tacticalChoices && chaseMoves == b.chaseMoves
                    && kiteMoves == b.kiteMoves && supportMoves == b.supportMoves;
        }
        String summary(String variant) {
            return String.format(Locale.ROOT,
                    "%-14s %-12s entities=%-6d time=%9.2f ms events=%-8d moves=%-8d candidates=%-12d " +
                            "aoe=%-6d heal=%-6d massHeal=%-6d nuke=%-6d cone=%-6d stun=%-6d dash=%-6d move/chase/kite=%d/%d/%d digest=%016x",
                    variant, scenario, entities, elapsedNs / 1e6, events, movements, candidateChecks,
                    aoeCasts, partyHeals, massHeals, nukes, cones, stuns, dashes,
                    movements, chaseMoves, kiteMoves, digest);
        }
    }

    static Result simulate(Scenario s, Mode m, Search q, int characters, int seconds, long seed) {
        return new World(s, m, q, characters, Math.multiplyExact(seconds, 1000), seed).run();
    }

    static void eq(boolean ok, String desc) { if (!ok) throw new AssertionError(desc); }

    static void testHealRules() {
        for (Search search : Search.values()) {
            World w = new World(Scenario.SIEGE, Mode.DETAIL, search, 160, 5000, 77);
            Actor h = w.actors[0];
            eq(h.speciality == Skill.MASS_HEAL, "first actor mass-healer");
            Actor allySameParty = w.actors[1], allyOtherParty = w.actors[9];
            Actor farAlly = w.actors[2], enemy = w.actors[80];
            setPosition(w, allySameParty, h.x, h.y);
            setPosition(w, allyOtherParty, h.x, h.y);
            setPosition(w, farAlly, h.x + HEAL_RADIUS + 1000, h.y);
            setPosition(w, enemy, h.x, h.y);
            allySameParty.hp -= 300;
            allyOtherParty.hp -= 300;
            farAlly.hp -= 300;
            enemy.hp -= 300;
            int one = w.areaHeal(h, Skill.PARTY_HEAL);
            eq(one == 1 && allySameParty.hp > allySameParty.maxHp - 300,
                    "party heal only heals wounded party member");
            eq(allyOtherParty.hp == allyOtherParty.maxHp - 300,
                    "party heal cannot heal a member of another party");
            int two = w.areaHeal(h, Skill.MASS_HEAL);
            eq(two >= 1 && allyOtherParty.hp > allyOtherParty.maxHp - 300,
                    "mass heal heals an ally outside the caster party");
            eq(farAlly.hp == farAlly.maxHp - 300, "mass heal respects radius");
            eq(enemy.hp == enemy.maxHp - 300, "mass heal cannot heal enemy");
            w.damage(enemy, allySameParty, allySameParty.hp, 99);
            eq(allySameParty.hp == 0, "target is dead");
            eq(w.heal(h, allySameParty, 900) == 0 && allySameParty.hp == 0,
                    "healing cannot resurrect a dead target");

            World capWorld = new World(Scenario.DENSE_SIEGE, Mode.DETAIL, search, 200, 5000, 87);
            Actor caster = capWorld.actors[0];
            for (int id = 1; id <= 45; id++) {
                Actor ally = capWorld.actors[id];
                setPosition(capWorld, ally, caster.x, caster.y);
                ally.hp -= 300;
            }
            int count = capWorld.areaHeal(caster, Skill.MASS_HEAL);
            eq(count == MAX_MASS_HEAL_TARGETS, "mass heal target cap");
            int healed = 0;
            for (int id = 1; id <= 45; id++) if (capWorld.actors[id].hp > capWorld.actors[id].maxHp - 300) healed++;
            eq(healed == MAX_MASS_HEAL_TARGETS, "mass-heal cap applies to exactly that many allies");
        }
        System.out.println("PASS party/mass heal scopes, range, cap, enemy safety, and no resurrection (SCAN & GRID)");
    }

    static void setPosition(World w, Actor a, int x, int y) {
        int oldX = a.x, oldY = a.y;
        a.x = x; a.y = y;
        if (w.grid != null) w.grid.moved(a, oldX, oldY);
    }

    static void checkCase(Scenario s, int n, int seconds, long seed) {
        Result baseline = simulate(s, Mode.DETAIL, Search.SCAN, n, seconds, seed);
        for (Mode mode : Mode.values()) for (Search search : Search.values()) {
            Result other = simulate(s, mode, search, n, seconds, seed);
            eq(baseline.sameState(other), "Mismatch " + s + " " + n + " " + mode + " " + search
                    + "\nbaseline=" + baseline + "\nactual=" + other);
        }
        System.out.printf("PASS %-12s characters=%-5d seconds=%-3d events=%-7d massHeal=%-6d targets=%-7d digest=%016x%n",
                s,n,seconds,baseline.events,baseline.massHeals,baseline.massTargetsHealed,baseline.digest);
    }

    static void selfTest() {
        testHealRules();
        for (long seed : new long[]{1L, 19L, 987654321L}) {
            checkCase(Scenario.PVE, 70, 12, seed);
            checkCase(Scenario.SKIRMISH, 160, 12, seed);
            checkCase(Scenario.SIEGE, 200, 12, seed);
            checkCase(Scenario.DENSE_SIEGE, 200, 12, seed);
        }
        checkCase(Scenario.PVE, 1000, 15, 42);
        checkCase(Scenario.SKIRMISH, 1000, 15, 42);
        checkCase(Scenario.SIEGE, 1000, 15, 42);
        eq(simulate(Scenario.SIEGE, Mode.DETAIL, Search.SCAN, 1000, 15, 42).massHeals > 0,
                "siege must exercise mass heal");
        System.out.println("PASS all four combinations produce exactly identical state");
    }

    public static void main(String[] args) {
        if (args.length == 0 || Arrays.asList(args).contains("--help")) {
            System.out.println("java CombatPrototype --test");
            System.out.println("java CombatPrototype --scenario siege --characters 7000 --seconds 15 --seed 42 --mode batch --search grid");
            return;
        }
        if (args[0].equals("--test")) { selfTest(); return; }
        Scenario s = Scenario.SKIRMISH;
        Mode m = Mode.BATCH;
        Search search = Search.GRID;
        int characters = 1000, seconds = 15;
        long seed = 42;
        for (int i = 0; i < args.length; i++) {
            if (i + 1 >= args.length) throw new IllegalArgumentException("Missing value for " + args[i]);
            switch (args[i]) {
                case "--scenario" -> s = Scenario.valueOf(args[++i].toUpperCase(Locale.ROOT));
                case "--characters" -> characters = Integer.parseInt(args[++i]);
                case "--seconds" -> seconds = Integer.parseInt(args[++i]);
                case "--seed" -> seed = Long.parseLong(args[++i]);
                case "--mode" -> m = Mode.valueOf(args[++i].toUpperCase(Locale.ROOT));
                case "--search" -> search = Search.valueOf(args[++i].toUpperCase(Locale.ROOT));
                default -> throw new IllegalArgumentException("Unknown option " + args[i]);
            }
        }
        Result result = simulate(s,m,search,characters,seconds,seed);
        System.out.println(result.summary(m + "/" + search));
    }
}
