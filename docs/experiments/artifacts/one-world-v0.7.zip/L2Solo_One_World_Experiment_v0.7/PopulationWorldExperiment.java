import java.util.*;

/** v0.7 synthetic vertical slice: one Account decision owner, one controlled Character, and separate Character wallets. */
public final class PopulationWorldExperiment {
    enum Activity { COMBAT, CRAFT, COURIER, SOCIAL }
    enum Goal { PROGRESS, PRODUCE, DELIVER, CONNECT, RAID, DEFEND_SIEGE }
    static final int[][] HUBS = {{2500,250},{24000,250},{46000,250},{62000,250}};
    static final int HUB_RADIUS = 600, FIELD_RADIUS = 240, WALK_SPEED = 950;
    static final class Wake {
        final int at, id;
        final long seq;
        Wake(int at,int id,long seq) { this.at=at; this.id=id; this.seq=seq; }
    }
    static final class State implements CombatPrototype.CombatEconomyHook {
        final int accountsCount, charactersCount;
        final long seed;
        final CombatPrototype.World world;
        final CharacterEconomyV07.Ledger ledger;
        final Activity[] activity;
        final Goal[] goals;
        final int[] activeCharacter, home, courierTarget, threatenedUntil, nextWake, socialParty;
        final boolean[] courierHomeward;
        final PriorityQueue<Wake> wakes = new PriorityQueue<>(Comparator.<Wake>comparingInt(w -> w.at).thenComparingLong(w -> w.seq));
        long wakeSequence;
        long initialAdena, initialOre, initialShots, loot, fees, usedShots, madeShots, usedOre;
        long fieldTrades, courierSteps, socialSteps, decisions, switches, threatened, eventWakes;
        long combatNs, decisionNs, economyNs;
        int combatAtStart, combatAtEnd, combatMin = Integer.MAX_VALUE, combatMax;
        int actingLastSecond, actingMax;
        final int[] lastCharacterActions, lastCounts = new int[4];
        final boolean[] raidOpportunity, siegeOpportunity;

        State(int n, int c, int seconds, long seed, CombatPrototype.Mode mode) {
            if (n < 30 || c < n || seconds < 2 || seconds > 120)
                throw new IllegalArgumentException("Need 30+ Accounts, at least one Character/Account, 2-120 game seconds");
            accountsCount = n; charactersCount = c; this.seed=seed;
            world = new CombatPrototype.World(CombatPrototype.Scenario.MIXED_WORLD, mode,
                    CombatPrototype.Search.GRID, c, seconds * 1000, seed);
            ledger = new CharacterEconomyV07.Ledger(n,c,4);
            activity = new Activity[n]; goals = new Goal[n];
            activeCharacter = new int[n]; home = new int[n]; courierTarget = new int[n];
            threatenedUntil = new int[n]; nextWake = new int[n]; socialParty = new int[n];
            courierHomeward = new boolean[n];
            raidOpportunity = new boolean[n]; siegeOpportunity = new boolean[n];
            lastCharacterActions = new int[c];
            Arrays.fill(courierTarget,-1); Arrays.fill(nextWake,Integer.MAX_VALUE); Arrays.fill(socialParty,-1);
            for (int id=0; id<n; id++) activeCharacter[id]=id;
            // Active Character and Main are distinct. Some Accounts run an alt in the raid/siege region.
            for (int cid=n; cid<c; cid++) {
                int id=ledger.owner[cid];
                if(preference(id,30)>28 && zone(cid,c)>=zone(activeCharacter[id],c))activeCharacter[id]=cid;
            }
            for (int id=0; id<n; id++) home[id]=zone(activeCharacter[id],c);
            // Every Character is owned by exactly one Account. Alts are present, but not all autonomously active.
            for (int cid=0; cid<c; cid++) {
                int id=ledger.owner[cid];
                var wallet=ledger.character[cid];
                long h=CombatPrototype.mix(seed ^ ((cid + 1L) * 0x9e3779b97f4a7c15L));
                wallet.adena=cid<n?350+Long.remainderUnsigned(h,800):30+Long.remainderUnsigned(h,110);
                wallet.ore=(int)Long.remainderUnsigned(h >>> 12, cid<n?12:4);
                wallet.shots=(int)Long.remainderUnsigned(h >>> 22,cid<n?18:5);
                initialAdena+=wallet.adena; initialOre+=wallet.ore; initialShots+=wallet.shots;
                world.setCombatActive(cid,false,0);
                if(cid!=activeCharacter[id])placeAtHub(cid,id); // dormant main or alt remains present
            }
            for(int id=0;id<n;id++) {
                var w=ledger.warehouse[id];
                long h=CombatPrototype.mix(seed+id*0x632be59bd9b4e019L);
                w.adena=20+Long.remainderUnsigned(h,100);
                w.ore=(int)Long.remainderUnsigned(h>>>11,4);
                w.shots=(int)Long.remainderUnsigned(h>>>23,6);
                initialAdena+=w.adena; initialOre+=w.ore; initialShots+=w.shots;
            }
            world.economyHook=this;
            for(int id=0;id<n;id++)reconsider(id,0,true);
        }
        static int zone(int cid,int c){int pve=c*45/100,pvp=c*20/100,raid=c*15/100;
            return cid<pve?0:cid<pve+pvp?1:cid<pve+pvp+raid?2:3;}
        static long dist2(int ax,int ay,int bx,int by){long dx=(long)ax-bx,dy=(long)ay-by;return dx*dx+dy*dy;}
        int px(int id) {return world.actors[activeCharacter[id]].x;}
        int py(int id) {return world.actors[activeCharacter[id]].y;}
        boolean atHub(int id) {int z=home[id];return dist2(px(id),py(id),HUBS[z][0],HUBS[z][1]) <= (long)HUB_RADIUS*HUB_RADIUS;}
        void placeAtHub(int cid,int id){
            var actor=world.actors[cid];int oldX=actor.x,oldY=actor.y;
            actor.x=HUBS[home[id]][0]+id%13*3;
            actor.y=HUBS[home[id]][1]+id%17*3;
            world.grid.moved(actor,oldX,oldY);
        }
        int preference(int id,int shift) {long h=CombatPrototype.mix(seed+(id+1L)*0x632be59bd9b4e019L);
            return (int)((h>>>shift)&63);}
        void requestWake(int id,int at,boolean external){
            if(at<nextWake[id]) {
                nextWake[id]=at;
                wakes.add(new Wake(at,id,wakeSequence++));
                if(external)eventWakes++;
            }
        }
        int goalScore(int id,Goal g,int now,boolean nearEnemy){
            var wallet=ledger.character[activeCharacter[id]];
            var wh=ledger.warehouse[id];
            var actor=world.actors[activeCharacter[id]];
            boolean supplyLow=wallet.shots<3;
            int threat=now<threatenedUntil[id]?65:0;
            return switch(g) {
                case PROGRESS -> 27+preference(id,0)+(nearEnemy?20:-7)+threat-(supplyLow?15:0)
                        -(actor.hp*3<actor.maxHp?18:0);
                case PRODUCE -> 19+preference(id,6)+((wallet.ore+wh.ore)>=2?29:-22)
                        +(wallet.shots<8?12:-12)-(wallet.adena<3?40:0);
                case DELIVER -> 18+preference(id,12)+(wallet.shots>4?18:-10)+(wallet.adena>20?6:-20);
                case CONNECT -> 22+preference(id,18)+(wallet.ore==0&&wallet.shots==0?12:0);
                case RAID -> raidOpportunity[id]?67+preference(id,0)/2+threat:Integer.MIN_VALUE/4;
                case DEFEND_SIEGE -> siegeOpportunity[id]?74+preference(id,6)/2+threat:Integer.MIN_VALUE/4;
            };
        }
        static Activity activityFor(Goal goal) {return switch(goal){
            case PROGRESS, RAID, DEFEND_SIEGE -> Activity.COMBAT;
            case PRODUCE -> Activity.CRAFT; case DELIVER -> Activity.COURIER; case CONNECT -> Activity.SOCIAL;
        };}
        void reconsider(int id,int now,boolean initial){
            long started=System.nanoTime();
            int cid=activeCharacter[id];
            boolean near=world.nearestEnemy(world.actors[cid],CombatPrototype.SEEK_RANGE)!=null;
            Goal previousGoal=goals[id],best=null;
            int max=Integer.MIN_VALUE;
            for(Goal candidate:Goal.values()) {
                int score=goalScore(id,candidate,now,near);
                if(score>max){max=score;best=candidate;}
            }
            if(previousGoal!=null&&previousGoal!=best&&max<goalScore(id,previousGoal,now,near)+12)
                best=previousGoal;
            Activity old=activity[id],chosen=activityFor(best);
            goals[id]=best; activity[id]=chosen; decisions++;
            if(old!=chosen){
                if(old!=null)switches++;
                world.setCombatActive(cid,chosen==Activity.COMBAT,now);
                if(initial&&chosen!=Activity.COMBAT)placeAtHub(cid,id);
                courierTarget[id]=-1;courierHomeward[id]=false;
            }
            // An Account sleeps until its next bounded review or a meaningful event wakes it.
            int interval=switch(chosen){case COMBAT->4500;case CRAFT->6200;case COURIER->5100;case SOCIAL->7600;};
            requestWake(id,now+interval+(id%7)*180,false);
            decisionNs+=System.nanoTime()-started;
        }
        void dueDecisions(int now){
            while(!wakes.isEmpty()&&wakes.peek().at<=now){
                Wake next=wakes.poll();
                if(nextWake[next.id]!=next.at)continue;
                nextWake[next.id]=Integer.MAX_VALUE;
                // Executed at the reached boundary, not backdated into the already processed combat window.
                reconsider(next.id,now,false);
            }
        }
        void triggerWorldEvent(int now){
            if(now==4000||now==6000||now==12000||now==14000){
                for(int id=0;id<accountsCount;id++){
                    if(now==4000&&home[id]==3&&preference(id,12)>20){siegeOpportunity[id]=true;requestWake(id,now,true);}
                    if(now==6000&&home[id]==2&&preference(id,18)>19){raidOpportunity[id]=true;requestWake(id,now,true);}
                    if(now==12000&&siegeOpportunity[id]){siegeOpportunity[id]=false;requestWake(id,now,true);}
                    if(now==14000&&raidOpportunity[id]){raidOpportunity[id]=false;requestWake(id,now,true);}
                }
            }
        }
        @Override public void onPlayerAction(int cid, CombatPrototype.Skill skill, int at){
            var w=ledger.character[cid];
            if(w.shots>0){w.shots--;usedShots++;}
            // Trigger only at the threshold crossing, not on every shotless attack.
            if(w.shots==1)requestWake(ledger.owner[cid],at,true);
        }
        @Override public void onLootAward(int cid,int at){
            ledger.character[cid].ore++;loot++;
        }
        @Override public void onPlayerAttacked(int cid,int at){
            int id=ledger.owner[cid];
            if(at+3000>threatenedUntil[id]){
                threatenedUntil[id]=at+3000;threatened++;
                requestWake(id,at,true);
            }
        }
        void list(int id,CharacterEconomyV07.Good good,int qty,int price){
            if(atHub(id))ledger.markets[home[id]].list(activeCharacter[id],good,qty,price);
        }
        int buy(int id,CharacterEconomyV07.Good good,int qty,int price){
            return atHub(id)?ledger.markets[home[id]].buy(activeCharacter[id],good,qty,price):0;
        }
        void marketStep(){
            for(int id=0;id<accountsCount;id++){
                var w=ledger.character[activeCharacter[id]];
                if(!atHub(id))continue;
                switch(activity[id]){
                    case CRAFT -> {
                        if(w.ore<4) {
                            ledger.throughWarehouse(activeCharacter[id],CharacterEconomyV07.Good.ORE,6,false,true);
                            if(w.ore<4)buy(id,CharacterEconomyV07.Good.ORE,8,6);
                        }
                        int make=Math.min(2,w.ore/2);
                        if(w.adena<5)ledger.throughWarehouseAdena(activeCharacter[id],20,false,true);
                        if(w.adena<make)make=(int)Math.min(make,w.adena);
                        if(make>0){w.ore-=2*make;w.shots+=12*make;w.adena-=make;
                            usedOre+=2L*make;madeShots+=12L*make;fees+=make;}
                        if(w.shots>15)list(id,CharacterEconomyV07.Good.SHOT,Math.min(24,w.shots-10),3);
                    }
                    case COMBAT -> {
                        if(w.ore>1)list(id,CharacterEconomyV07.Good.ORE,w.ore-1,4);
                        if(w.shots<3) {
                            ledger.throughWarehouse(activeCharacter[id],CharacterEconomyV07.Good.SHOT,8,false,true);
                            if(w.shots<3)buy(id,CharacterEconomyV07.Good.SHOT,8,4);
                        }
                    }
                    case COURIER -> {
                        if(w.ore>0)list(id,CharacterEconomyV07.Good.ORE,w.ore,5);
                        if(w.shots<7){
                            ledger.throughWarehouse(activeCharacter[id],CharacterEconomyV07.Good.SHOT,8,false,true);
                            if(w.shots<7)buy(id,CharacterEconomyV07.Good.SHOT,12,4);
                        }
                    }
                    case SOCIAL -> {
                        // Social activity does not mint material or currency.
                    }
                }
            }
        }
        void move(int id,int tx,int ty){
            var actor=world.actors[activeCharacter[id]];
            long dx=(long)tx-actor.x,dy=(long)ty-actor.y;
            double distance=Math.sqrt(dx*dx+dy*dy);
            if(distance<=0)return;
            int oldX=actor.x,oldY=actor.y;
            double speed=Math.min(distance,WALK_SPEED);
            actor.x+=(int)Math.round(dx*speed/distance);actor.y+=(int)Math.round(dy*speed/distance);
            world.grid.moved(actor,oldX,oldY);courierSteps++;
        }
        int localFighter(int id){
            // Bounded search: avoid scanning all 10k Character for each courier.
            int start=Math.floorMod((int)CombatPrototype.mix(seed+id),accountsCount);
            for(int k=0;k<Math.min(accountsCount,128);k++){
                int target=(start+k)%accountsCount;
                if(target!=id&&home[target]==home[id]&&activity[target]==Activity.COMBAT)return activeCharacter[target];
            }
            return -1;
        }
        void exchange(int id,int cid){
            int otherId=ledger.owner[cid];if(id==otherId)return;
            var courier=ledger.character[activeCharacter[id]];
            var fighter=ledger.character[cid];
            var target=world.actors[cid];
            if(dist2(px(id),py(id),target.x,target.y)>(long)FIELD_RADIUS*FIELD_RADIUS)return;
            int ore=Math.min(3,Math.min(fighter.ore,(int)Math.min(Integer.MAX_VALUE,courier.adena/4)));
            if(ore>0){fighter.ore-=ore;courier.ore+=ore;courier.adena-=ore*4L;fighter.adena+=ore*4L;fieldTrades++;}
            int shots=fighter.shots<3?Math.min(5,Math.min(courier.shots,(int)Math.min(Integer.MAX_VALUE,fighter.adena/4))):0;
            if(shots>0){courier.shots-=shots;fighter.shots+=shots;fighter.adena-=shots*4L;courier.adena+=shots*4L;fieldTrades++;}
        }
        void movementAndCourierStep(){
            for(int id=0;id<accountsCount;id++){
                Activity a=activity[id];
                if(a==Activity.COMBAT)continue;
                if(a!=Activity.COURIER){
                    if(!atHub(id))move(id,HUBS[home[id]][0],HUBS[home[id]][1]);
                    continue;
                }
                int cid=courierTarget[id];
                if(cid<0||activity[ledger.owner[cid]]!=Activity.COMBAT){
                    courierTarget[id]=cid=localFighter(id);courierHomeward[id]=false;
                }
                if(cid<0){move(id,HUBS[home[id]][0],HUBS[home[id]][1]);continue;}
                if(courierHomeward[id]){
                    move(id,HUBS[home[id]][0],HUBS[home[id]][1]);
                    if(atHub(id)){courierTarget[id]=-1;courierHomeward[id]=false;}
                } else {
                    var target=world.actors[cid];move(id,target.x,target.y);
                    if(dist2(px(id),py(id),target.x,target.y)<=(long)FIELD_RADIUS*FIELD_RADIUS){
                        exchange(id,cid);courierHomeward[id]=true;
                    }
                }
            }
        }
        void socialStep(){
            for(int id=0;id<accountsCount;id++)if(activity[id]==Activity.SOCIAL){
                socialParty[id]=home[id]*100000+id/9;socialSteps++;
            }
        }
        void conservation(){
            long a=0,o=0,s=0;
            for(var w:ledger.character){
                if(w.adena<0||w.ore<0||w.shots<0)throw new AssertionError("Negative Character wallet");
                a+=w.adena;o+=w.ore;s+=w.shots;
            }
            for(var w:ledger.warehouse){
                if(w.adena<0||w.ore<0||w.shots<0)throw new AssertionError("Negative Warehouse wallet");
                a+=w.adena;o+=w.ore;s+=w.shots;
            }
            for(var m:ledger.markets){o+=m.escrow(CharacterEconomyV07.Good.ORE);
                s+=m.escrow(CharacterEconomyV07.Good.SHOT);}
            if(a+fees!=initialAdena||o+usedOre!=initialOre+loot||s+usedShots!=initialShots+madeShots)
                throw new AssertionError("Conservation failed: adena="+a+" ore="+o+" shots="+s);
        }
        long hash(){
            long h=ledger.digest();
            for(int id=0;id<accountsCount;id++){
                long[] fields={id,activeCharacter[id],home[id],goals[id].ordinal(),activity[id].ordinal(),
                    courierTarget[id],courierHomeward[id]?1:0,threatenedUntil[id],
                    raidOpportunity[id]?1:0,siegeOpportunity[id]?1:0,socialParty[id],nextWake[id]};
                for(long f:fields)h=(h^f)*0x100000001b3L;
            }
            return h;
        }
        int countCombat(){int count=0;
            for(int cid=0;cid<charactersCount;cid++)if(world.actors[cid].combatActive)count++;
            return count;
        }
        void step(int toMs){
            if(toMs%1000!=0)throw new IllegalArgumentException("Whole seconds only");
            long tick=System.nanoTime();world.advanceTo(toMs);combatNs+=System.nanoTime()-tick;
            tick=System.nanoTime();triggerWorldEvent(toMs);dueDecisions(toMs);
            marketStep();movementAndCourierStep();socialStep();conservation();
            economyNs+=System.nanoTime()-tick;
            int active=countCombat();combatAtEnd=active;
            combatMin=Math.min(combatMin,active);combatMax=Math.max(combatMax,active);
            int acted=0;
            for(int cid=0;cid<charactersCount;cid++){
                var actor=world.actors[cid];int actions=actor.attacks+actor.spells;
                if(actions>lastCharacterActions[cid])acted++;
                lastCharacterActions[cid]=actions;
            }
            actingLastSecond=acted;actingMax=Math.max(actingMax,acted);
            Arrays.fill(lastCounts,0);
            for(Activity a:activity)lastCounts[a.ordinal()]++;
        }
        Result finish(long elapsed){
            var b=world.run();long trades=fieldTrades;
            for(var m:ledger.markets)trades+=m.matches;
            return new Result(accountsCount,charactersCount,combatAtStart,combatAtEnd,combatMin,combatMax,
                    actingLastSecond,actingMax,decisions,eventWakes,switches,threatened,b.events(),b.combatActions(),b.healEffects(),
                    loot,trades,madeShots,usedShots,courierSteps,socialSteps,ledger.warehouseTransfers,
                    elapsed,combatNs,decisionNs,economyNs,
                    lastCounts[0],lastCounts[1],lastCounts[2],lastCounts[3],hash(),b.digest());
        }
    }
    record Result(int accounts,int characters,int initialCombat,int finalCombat,int minCombat,int maxCombat,
                  int actedLastSecond,int actedMax,long decisions,long eventWakes,long activityChanges,long threatEvents,
                  long events,long actions,long heals,long loot,long trades,long crafted,long consumed,
                  long courierSteps,long socialSteps,long warehouseTransfers,
                  long elapsedNs,long combatNs,long decisionNs,long economyNs,
                  long combatAccounts,long craftAccounts,long courierAccounts,long socialAccounts,
                  long economyHash,long combatHash) {
        boolean same(Result b) {return economyHash==b.economyHash&&combatHash==b.combatHash&&events==b.events
                &&trades==b.trades&&loot==b.loot&&activityChanges==b.activityChanges&&warehouseTransfers==b.warehouseTransfers;}
    }
    static Result run(int accounts,int characters,int seconds,long seed,CombatPrototype.Mode mode){
        long start=System.nanoTime(); // Includes world/ledger initialization, unlike the historical v0.6 timing.
        var state=new State(accounts,characters,seconds,seed,mode);
        state.combatAtStart=state.countCombat();
        for(int t=1000;t<=seconds*1000;t+=1000)state.step(t);
        state.conservation();return state.finish(System.nanoTime()-start);
    }
    static void test(){
        CharacterEconomyV07.testLedger();
        for(long seed:new long[]{7,42,901})for(int accounts:new int[]{300,700})
            for(int chars:new int[]{accounts,accounts+accounts/5}){
                var detail=run(accounts,chars,16,seed,CombatPrototype.Mode.DETAIL);
                var batch=run(accounts,chars,16,seed,CombatPrototype.Mode.BATCH);
                if(!detail.same(batch))throw new AssertionError("DETAIL/BATCH diverged: "+detail+" / "+batch);
                if(detail.initialCombat>=chars)throw new AssertionError("All Character preassigned to combat");
                if(detail.initialCombat>accounts||detail.finalCombat>accounts)
                    throw new AssertionError("Multiple autonomous active Character per Account");
                // A Character can act during a second then switch Activity at its end.
                if(detail.actedLastSecond<0||detail.actedLastSecond>chars)
                    throw new AssertionError("Invalid actors performing combat actions");
                if(detail.activityChanges==0||detail.eventWakes==0||detail.warehouseTransfers==0)
                    throw new AssertionError("Decision/event/warehouse slices not exercised: "+detail);
                if(detail.actions==0||detail.heals==0||detail.trades==0||detail.courierSteps==0)
                    throw new AssertionError("World subsystems not exercised: "+detail);
            }
        var s=new State(300,360,10,42,CombatPrototype.Mode.BATCH);
        for(int id=0;id<300;id++)for(int cid=id;cid<360;cid+=300)
            if(cid!=s.activeCharacter[id]&&s.world.actors[cid].combatActive)
                throw new AssertionError("Dormant Character mistakenly controls itself");
        int alt=s.activeCharacter[0]==0?300:0;
        var passive=s.world.actors[alt];
        var npc=s.world.actors[360];
        int oldHp=passive.hp;int id=s.ledger.owner[alt];
        s.world.damage(npc,passive,15,200);
        if(passive.hp!=oldHp-15||s.threatenedUntil[id]<=200)
            throw new AssertionError("Alt missing from world or threat not reported to owner");
        // A Character's goods cannot be purchased/sold by another Character of the same Account automatically.
        var a=s.ledger.character[0];var b=s.ledger.character[300];
        int before=b.ore;a.ore+=100;
        if(b.ore!=before)throw new AssertionError("Character wallet isolation");
        System.out.println("PASS v0.7 ownership, warehouse, threat wake, account controller, DETAIL/BATCH, conservation");
    }
    public static void main(String[] args){
        if(Arrays.asList(args).contains("--test")){test();return;}
        int accounts=7000,characters=-1,seconds=8,repeats=1;long seed=42;
        for(int i=0;i<args.length;i++){
            if(i+1>=args.length)throw new IllegalArgumentException("Missing value for "+args[i]);
            switch(args[i]){
                case "--accounts" -> accounts=Integer.parseInt(args[++i]);
                case "--characters" -> characters=Integer.parseInt(args[++i]);
                case "--seconds" -> seconds=Integer.parseInt(args[++i]);
                case "--repeats" -> repeats=Integer.parseInt(args[++i]);
                case "--seed" -> seed=Long.parseLong(args[++i]);
                case "--combat" -> throw new IllegalArgumentException("--combat removed: participation is decided by Account goals");
                default -> throw new IllegalArgumentException("Unknown option "+args[i]);
            }
        }
        if(characters<0)characters=accounts;
        if(repeats<1)throw new IllegalArgumentException("Need repeats >= 1");
        System.out.println("mode,accounts,present_characters,combat_initial,combat_final,combat_min,combat_max,acted_last_second,acted_max,decisions,event_wakes,activity_changes,threat_events,events,actions,heals,loot,trades,crafted,consumed,courier_moves,social_events,warehouse_transfers,elapsed_ms,combat_ms,decision_ms,economy_ms,accounts_combat,accounts_craft,accounts_courier,accounts_social,economy_hash,combat_hash");
        for(int iteration=0;iteration<repeats;iteration++){
            var detail=run(accounts,characters,seconds,seed,CombatPrototype.Mode.DETAIL);
            var batch=run(accounts,characters,seconds,seed,CombatPrototype.Mode.BATCH);
            if(!detail.same(batch))throw new AssertionError("DETAIL != BATCH at run "+iteration);
            for(var r:new Result[]{detail,batch}){
                System.out.printf(Locale.ROOT,
                    "%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,%d,%d,%d,%d,%016x,%016x%n",
                    r==detail?"DETAIL":"BATCH",r.accounts,r.characters,r.initialCombat,r.finalCombat,r.minCombat,r.maxCombat,
                    r.actedLastSecond,r.actedMax,r.decisions,r.eventWakes,r.activityChanges,r.threatEvents,r.events,
                    r.actions,r.heals,r.loot,r.trades,r.crafted,r.consumed,r.courierSteps,r.socialSteps,r.warehouseTransfers,
                    r.elapsedNs/1e6,r.combatNs/1e6,r.decisionNs/1e6,r.economyNs/1e6,
                    r.combatAccounts,r.craftAccounts,r.courierAccounts,r.socialAccounts,r.economyHash,r.combatHash);
            }
        }
    }
}
