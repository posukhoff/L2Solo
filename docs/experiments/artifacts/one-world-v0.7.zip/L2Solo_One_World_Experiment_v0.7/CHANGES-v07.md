# v0.7 changes relative to v0.6

- **Modified:** `PopulationWorldExperiment.java` — Account goal evaluation, bounded wake queue, regional events, one selected Character per Account, individual wallets and safe trade/warehouse integration, new metrics and conservation.
- **Modified:** `PopulationTrace.java` — new decision and warehouse counters.
- **Added:** `CharacterEconomyV07.java` — independent Character inventories, Account warehouse, separate market escrow, ownership tests.
- **Modified:** `RUN.sh` — compile new class, tests, 7k and 10k cases, trace.
- **Retained:** `CombatPrototype.java` (shared combat/skill state, unchanged); `WorldEconomyExperiment.java` (historical v0.4 benchmark, unchanged); `SkillRulesTest.java` (unchanged).
- **Archived:** v0.6 benchmark CSVs under `historical-v06/` (not v0.7 data).
- **Added results:** `benchmark-v07-7k.csv`, `benchmark-v07-10k.csv`, `benchmark-v07-7k-30s.csv`, `benchmark-v07-longrun.csv`, `activity-trace-v07-7k.csv`, `memory-v07-7k-30s.txt`.

No GitHub interaction, external dependency, or production integration. The source demonstrates a limited **experimental implementation**, not an accepted ADR-002.
