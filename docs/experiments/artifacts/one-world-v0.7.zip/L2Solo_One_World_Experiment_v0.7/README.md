# L2Solo — One World Experiment v0.7

**Status:** Tested synthetic Java 21 prototype; no GitHub sync; no dependencies. This is not the L2Solo production server, an authentic Lineage II economy, or a demonstration of 7,000 real autonomous clients on a consumer PC.

## Why this version exists

The v0.6 benchmark correctly removed a preallocated 5,600-COMBAT quota, but still used **Account-level inventory** and set **all Character of an Account** to the same activity. This conflated player identity, the controller, individual Character and assets, especially at 7,000 Account / 10,000 Character. The v0.7 vertical slice fixes those semantics without replacing the unified combat workload.

### Implemented

1. **One Account decision owner, one currently controlled Character.** A Character still has a unique Account owner. `activeCharacter` is separate from the Account's Main (`id` in this fixture). Some Accounts initially control an alt, including in raid/siege areas, while non-controlled Character stay present and targetable in the one simulated world. No runtime character swapping yet, and no concurrent multi-character controllers per Account.
2. **Character-specific economy.** `CharacterEconomyV07.Ledger` owns independent Character inventories for adena, ore and shots. Combat loot and shot consumption credit/debit the *acting Character*; crafting, field barter and order matching exchange exact Character resources. No Account-wide invisible inventory.
3. **Account Warehouse.** One inventory per Account, distinct from its Character inventories. The synthetic warehouse method requires explicit `nearNpc=true` and callers authorize it only when at their home hub; deposits and withdrawals of ore, shots and adena are direct, bounded transfers. There is **no CP Warehouse**. This does not simulate actual warehouse NPC dialogue, cooldowns, storage fees or travel time.
4. **Market escrow per Character.** A listing removes goods from the seller's Character inventory into order escrow. A purchase exchanges adena and goods once. Self-orders cannot be purchased and no longer block valid orders from a different Account behind them.
5. **Account Goal slice.** Six synthetic Goals (`PROGRESS`, `PRODUCE`, `DELIVER`, `CONNECT`, `RAID`, `DEFEND_SIEGE`) map onto four Activities (`COMBAT`, `CRAFT`, `COURIER`, `SOCIAL`). A stable preference plus stock, nearby threats and scripted local opportunities affects priorities. Decisions use hysteresis. This is **not** an approved comprehensive ADR-002 Goal/Activity/Obligation architecture.
6. **Scheduled/event-based reconsideration.** Each Account has a bounded next wake-up; a queue processes due Accounts. Threat and supply events, plus regional raid/siege opportunities, can request earlier reviews. No global AI check every two game seconds. In this synthetic test, many combat callbacks still generate threat updates; advanced event coalescing is future work.
7. **One World correctness.** PvE, PvP, raids, siege, NPCs, movement, merchant transactions and conservation share one world clock and state. The combat mechanics remain deliberately simplified. DETAIL and BATCH are **event scheduler implementations**, not a proven Hot/Cold engine.

### Invariants checked

- Every Character has one owner and independently held resources.
- Only one controlled Character per Account in this benchmark; passive Character persist and can be attacked.
- Resources cannot transfer between two Character of one Account without a modeled ledger transaction.
- Warehouses require caller-confirmed hub/NPC access; no remote withdrawals in the tested API.
- An order cannot list more goods than the seller owns, double-fill or duplicate escrow.
- Per simulated second: `Adena + crafting fees == initial Adena`; `Ore + ore used for crafting == initial Ore + drops`; `Shots + consumed shots == initial Shots + crafted shots` (including wallets, warehouses, and escrow).
- DETAIL and BATCH produce identical final combat/economy digests, and matching events/trades/loot, across multiple seeds and population sizes.

## Run

```bash
# Requires JDK 21, Linux/macOS shell for RUN.sh
./RUN.sh

# Or compile and run manually:
javac -encoding UTF-8 CombatPrototype.java WorldEconomyExperiment.java CharacterEconomyV07.java PopulationWorldExperiment.java PopulationTrace.java SkillRulesTest.java
java -Xmx1g SkillRulesTest
java -Xmx1g PopulationWorldExperiment --test
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 7000 --seconds 8 --repeats 1
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 10000 --seconds 8 --repeats 1
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 7000 --seconds 30 --repeats 1
java -Xmx2g PopulationTrace 7000 7000 16 42
```

`--accounts`: AI Account count, `--characters`: present Character (at least Accounts), `--seconds`: 2–120 simulated game seconds, `--seed`: deterministic fixture seed, `--repeats`: independent paired DETAIL/BATCH runs. `--combat` is intentionally unsupported.

## Preliminary benchmark (cloud environment, one run, seed 42)

Timings include **initial world and ledger construction** in v0.7, unlike historical v0.6 timings; avoid naive version-to-version speed claims. The measured wall-clock durations include each simulation once; `elapsed_ms` is from each individual run. RSS includes JVM runtime and both runs of the 30-second paired process.

| Scenario | Simulated seconds | DETAIL | BATCH | Exact digest match |
| --- | ---: | ---: | ---: | :---: |
| 7,000 Account / 7,000 Character | 8 | 3,416.928 ms | 2,272.064 ms | YES |
| 7,000 Account / 10,000 Character | 8 | 3,501.320 ms | 2,932.079 ms | YES |
| 7,000 Account / 7,000 Character | 30 | 10,400.679 ms | 9,155.577 ms | YES |
| 700 Account / 1,000 Character (long-run correctness) | 60 | 931.203 ms | 709.816 ms | YES |

The 7k/30-second **paired** process peaked at 246,308 kB resident set size (about 241 MiB), from `/usr/bin/time -v`. One cloud run is *not* a representative p95 benchmark or a production memory estimate. CSV files include all counters and final digests. `historical-v06/` contains original results only, not v0.7 benchmarks.

### Reporting semantics

- `accounts`: owner identities; `present_characters`: all player Character, including dormant mains and alts.
- `combat_initial`, `combat_final`: Character with combat activity enabled; no preset quota.
- `acted_last_second`: distinct Character with an attack or skill in the **last game second**; may be different from combat intent at that second's end.
- `decisions`: all Goal re-evaluations, including construction-time choices.
- `event_wakes`: external wake requests accepted earlier than a pending scheduled wake, not the number of unique Account awakened.
- `warehouse_transfers`: successful direct item/adena movements between an active Character and its Account Warehouse.
- `economy_hash` + `combat_hash`: deterministic result digests, not cryptographic attestation.

## Known limits and next evidence needed

- Population layout (`45%` PvE, `20%` skirmish, `15%` raid, `20%` siege by Character ID) **is a fixed encounter stress fixture**, not an assertion about realistic player behavior; Account choices are emergent only within this staged environment.
- Starting inventory and warehouse balances are seeded; no real-world resource acquisition or L2 loot economy. No persistence, concurrency, multiplayer network, auth, official NPC warehouse dialogue, Clan Warehouse rights or true offline shop.
- No realistic geodata, line-of-sight or pathfinding. Noncombat characters are placed near regional hubs at initialization; movement afterward is incremental. An initial active-alt choice is a fixture and does **not** implement logging into another Character, switching in combat, or safe handoffs.
- No complete Goal/Activity/Obligation hierarchy, party/CP/clan orders, delegated human control, knowledge/fog-of-war, travel budget, sustained market equilibrium or real L2 formulas. Regional events are scripted stimuli, not organic clans choosing to siege.
- No validated 24/7 continuity, server restart, full Hot/Cold state handoff or true hardware target test. DETAIL/BATCH equality only covers event scheduler representations of this simplified world.

**Next:** Write a focused ADR-002 decision contract; validate one Account with multiple Character switching over time and a realistic location/warehouse transaction; replace scripted initial goods and regional encounters incrementally; compare continuous benchmarks and CPU/RAM on the target local PC before choosing more threads, ECS, Workers, Rust, GPU or other infrastructure.
