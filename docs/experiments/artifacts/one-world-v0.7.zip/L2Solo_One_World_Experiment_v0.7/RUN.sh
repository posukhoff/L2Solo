#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
javac -encoding UTF-8 CombatPrototype.java WorldEconomyExperiment.java CharacterEconomyV07.java PopulationWorldExperiment.java PopulationTrace.java SkillRulesTest.java
java -Xmx1g SkillRulesTest
java -Xmx1g PopulationWorldExperiment --test
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 7000 --seconds 8 --repeats 1
java -Xmx2g PopulationWorldExperiment --accounts 7000 --characters 10000 --seconds 8 --repeats 1
java -Xmx2g PopulationTrace 7000 7000 16 42
