/** Targeted v0.3 tactical correctness checks, no external test library. */
public final class SkillRulesTest {
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }

    static CombatPrototype.World world() {
        CombatPrototype.World w = new CombatPrototype.World(CombatPrototype.Scenario.SKIRMISH,
                CombatPrototype.Mode.DETAIL, CombatPrototype.Search.GRID, 16, 5000, 33);
        for (int id = 0; id < w.actors.length; id++)
            CombatPrototype.setPosition(w, w.actors[id], 10000 * (id + 1), 10000 * (id + 1));
        return w;
    }
    static void place(CombatPrototype.World w, int id, int x, int y) {
        CombatPrototype.setPosition(w, w.actors[id], x, y);
    }

    static void testRangedAttack() {
        CombatPrototype.World w = world();
        check(w.actors[5].role == CombatPrototype.Role.ARCHER, "archer role");
        place(w, 5, 0, 0); place(w, 8, 400, 0);
        int hp = w.actors[8].hp;
        w.performAction(w.actors[5], 100);
        check(w.actors[5].attacks == 1 && w.actors[8].hp < hp, "ranged shot works beyond melee range");
        System.out.println("PASS ranged attack has different range than melee");
    }

    static void testMageAoE() {
        CombatPrototype.World w = world();
        check(w.actors[7].role == CombatPrototype.Role.MAGE, "mage role");
        place(w, 7, 0, 0); place(w, 8, 350, 0); place(w, 9, 380, 0);
        w.performAction(w.actors[7], 100);
        check(w.aoeCasts == 1 && w.actors[8].hp < w.actors[8].maxHp &&
                w.actors[9].hp < w.actors[9].maxHp, "mage chooses AoE if targets are clustered");
        int cooldown = w.actors[7].skillReadyAt[CombatPrototype.Skill.AOE_DAMAGE.ordinal()];
        check(cooldown > 100, "AoE cooldown created");
        w.performAction(w.actors[7], 200);
        check(w.aoeCasts == 1, "AoE not spammed while on cooldown");
        System.out.println("PASS situational AoE and skill cooldown");
    }

    static void testStun() {
        CombatPrototype.World w = world();
        check(w.actors[13].role == CombatPrototype.Role.CONTROLLER, "controller role");
        place(w, 13, 0, 0); place(w, 1, 180, 0);
        w.performAction(w.actors[13], 100);
        check(w.stuns == 1 && w.actors[1].stunnedUntil == 100 + CombatPrototype.STUN_DURATION,
                "controller applies stun");
        int oldX = w.actors[1].x;
        w.move(w.actors[1], 200);
        check(w.actors[1].x == oldX && w.movementEvents == 0, "stunned actor cannot move");
        int oldAttacks = w.actors[1].attacks;
        w.performAction(w.actors[1], 300);
        check(w.actors[1].attacks == oldAttacks, "stunned actor cannot attack");
        System.out.println("PASS stun prevents actions and movement until expiry");
    }

    static void testDash() {
        CombatPrototype.World w = world();
        check(w.actors[1].role == CombatPrototype.Role.FIGHTER, "fighter role");
        place(w, 1, 0, 0); place(w, 8, 500, 0);
        w.performAction(w.actors[1], 100);
        check(w.dashes == 1 && w.actors[1].x > 0 && w.actors[1].x <= CombatPrototype.DASH_STEP,
                "dash closes distance but does not exceed limit");
        check(w.actors[1].mp == w.actors[1].maxMp - CombatPrototype.MP_COST[CombatPrototype.Skill.DASH.ordinal()],
                "dash consumes mana");
        System.out.println("PASS dash skill moves and consumes resources");
    }

    static void testConeDirection() {
        CombatPrototype.World w = world();
        place(w, 1, 0, 0); place(w, 8, 100, 0); place(w, 9, 120, 30); place(w, 10, -190, 0);
        int behind = w.actors[10].hp;
        w.performAction(w.actors[1], 100);
        check(w.cones == 1 && w.actors[8].hp < w.actors[8].maxHp && w.actors[9].hp < w.actors[9].maxHp,
                "fighter uses cone for multiple targets in front");
        check(w.actors[10].hp == behind, "cone cannot hit enemy behind caster");
        System.out.println("PASS directional cone ignores enemies behind caster");
    }

    static void testHealerDecisions() {
        CombatPrototype.World w = world();
        place(w, 0, 0, 0); place(w, 1, 60, 0);
        w.actors[1].hp -= 300;
        w.performAction(w.actors[0], 100);
        check(w.partyHeals == 1 && w.massHeals == 0, "healer chooses party heal for single ally");
        place(w, 2, 70, 0); place(w, 3, 80, 0);
        w.actors[1].hp -= 200; w.actors[2].hp -= 300; w.actors[3].hp -= 300;
        w.performAction(w.actors[0], 300);
        check(w.massHeals == 1, "healer switches to mass heal for several wounded allies");
        System.out.println("PASS heal selection responds to number of injured allies");
    }

    static void testPositioning() {
        CombatPrototype.World w = world();
        place(w, 7, 0, 0); place(w, 8, 100, 0);
        w.move(w.actors[7], 100);
        check(w.actors[7].x < 0 && w.kiteMoves == 1, "mage moves away from close enemy");
        CombatPrototype.World next = world();
        place(next, 1, 0, 0); place(next, 8, 750, 0);
        next.move(next.actors[1], 100);
        check(next.actors[1].x > 0 && next.chaseMoves == 1, "fighter pursues target");
        System.out.println("PASS kite and pursuit depend on tactical role");
    }

    public static void main(String[] args) {
        testRangedAttack(); testMageAoE(); testStun(); testDash();
        testConeDirection(); testHealerDecisions(); testPositioning();
        System.out.println("PASS all targeted v0.3 skill/movement rules");
    }
}
